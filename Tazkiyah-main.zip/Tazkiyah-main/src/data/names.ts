export interface NameOfAllah {
  id: number;
  name: string;
  arabic: string;
  meaning: string;
  description: string;
  audio: string;
}

export const allNames: NameOfAllah[] = [
  {
    id: 1,
    name: "Ar-Rahman",
    arabic: "الرحمن",
    meaning: "The Most Gracious",
    description: "The One who wills goodness and mercy for all His creatures. His mercy encompasses every single soul, every breath, and every heartbeat. In the depths of your despair, remember that His grace is wider than your pain. He provides for the believer and the disbeliever alike, showing the vastness of His love. Let your heart rest in the knowledge that you are never outside His infinite care.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/01-Ar-Rahman.mp3"
  },
  {
    id: 2,
    name: "Ar-Rahim",
    arabic: "الرحيم",
    meaning: "The Most Merciful",
    description: "The One who acts with extreme mercy specifically for those who seek Him. While Ar-Rahman is general, Ar-Rahim is the intimate mercy that heals the broken heart. He forgives the sins that you thought were unforgivable and welcomes you back with open arms. Every tear you shed in solitude is seen and valued by the Most Merciful. Trust in His specific plan for you, for it is crafted with divine tenderness.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/02-Ar-Rahim.mp3"
  },
  {
    id: 3,
    name: "Al-Malik",
    arabic: "الملك",
    meaning: "The Sovereign",
    description: "The Absolute Ruler of the universe, to whom belongs everything in the heavens and the earth. When the world feels chaotic and out of control, remember that Al-Malik is in command. No king or power on earth can compare to His eternal and just sovereignty. Your worries are small in the hands of the King of Kings who manages every affair. Find peace in surrendering your will to the One who truly owns your soul.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/03-Al-Malik.mp3"
  },
  {
    id: 4,
    name: "Al-Quddus",
    arabic: "القدوس",
    meaning: "The Pure One",
    description: "The One who is absolutely pure and free from any imperfection or flaw. He is beyond human comprehension, untouched by the limitations of time and space. When you feel stained by the world, turn to Al-Quddus to purify your intentions and your heart. His holiness is a beacon of light that guides us away from the darkness of our own egos. To praise Him is to align oneself with the ultimate source of all that is good.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/04-Al-Quddus.mp3"
  },
  {
    id: 5,
    name: "As-Salam",
    arabic: "السلام",
    meaning: "The Source of Peace",
    description: "The One who is the very essence of peace and the provider of security. In a world filled with noise and conflict, He is the sanctuary where the soul finds rest. True tranquility can only be found by connecting with the Source of Peace Himself. He protects His servants from harm and grants them a serenity that transcends circumstances. May His peace descend upon your heart and radiate through your entire being.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/05-As-Salam.mp3"
  },
  {
    id: 6,
    name: "Al-Mu'min",
    arabic: "المؤمن",
    meaning: "The Giver of Faith",
    description: "The One who witnessed for Himself that no one is God but Him. And He witnessed for His believers that they are truthful in their belief that no one is God but Him. He is the source of all security and the one who removes fear from the hearts of the believers.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/06-Al-Mumin.mp3"
  },
  {
    id: 7,
    name: "Al-Muhaymin",
    arabic: "المهيمن",
    meaning: "The Guardian",
    description: "The One who witnesses the creation and encompasses it. He is the overseer who protects and manages all affairs. Nothing escapes His gaze, and His guardianship is the ultimate safety for the soul.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/07-Al-Muhaymin.mp3"
  },
  {
    id: 8,
    name: "Al-Aziz",
    arabic: "العزيز",
    meaning: "The Almighty",
    description: "The Defeater who is not defeated. He is the one whose power is absolute and whose will is always executed. His might is balanced with wisdom, ensuring that every action is purposeful and just.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/08-Al-Aziz.mp3"
  },
  {
    id: 9,
    name: "Al-Jabbar",
    arabic: "الجبار",
    meaning: "The Compeller",
    description: "The One who repairs all broken things and completes that which is incomplete. He is the one who compels the hearts to find peace in Him and ensures that His divine decree is fulfilled.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/09-Al-Jabbar.mp3"
  },
  {
    id: 10,
    name: "Al-Mutakabbir",
    arabic: "المتكبر",
    meaning: "The Supreme",
    description: "The One who is supreme in His essence and attributes. He is far above any flaw or resemblance to His creation. His greatness is the only true greatness, and all other pride is but a shadow.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/10-Al-Mutakabbir.mp3"
  },
  {
    id: 11,
    name: "Al-Khaliq",
    arabic: "الخالق",
    meaning: "The Creator",
    description: "The One who brings things from non-existence into existence. He designs and proportions everything with perfect knowledge and intent.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/11-Al-Khaliq.mp3"
  },
  {
    id: 12,
    name: "Al-Bari'",
    arabic: "البارئ",
    meaning: "The Evolver",
    description: "The One who creates without a pre-existing model. He brings order and harmony to the creation, ensuring that every part fits perfectly into the whole.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/12-Al-Bari.mp3"
  },
  {
    id: 13,
    name: "Al-Musawwir",
    arabic: "المصور",
    meaning: "The Fashioner",
    description: "The One who gives everything its unique form and beauty. He is the ultimate artist who paints the world with infinite variety and detail.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/13-Al-Musawwir.mp3"
  },
  {
    id: 14,
    name: "Al-Ghaffar",
    arabic: "الغفار",
    meaning: "The Repeatedly Forgiving",
    description: "The One who forgives time and time again. No matter how many times we fall, His door of forgiveness is always open to those who return to Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/14-Al-Ghaffar.mp3"
  },
  {
    id: 15,
    name: "Al-Qahhar",
    arabic: "القهار",
    meaning: "The Subduer",
    description: "The One who prevails over all things. His power is irresistible, and all of creation is subject to His divine will and authority.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/15-Al-Qahhar.mp3"
  },
  {
    id: 16,
    name: "Al-Wahhab",
    arabic: "الوهاب",
    meaning: "The Bestower",
    description: "The One who gives freely without expecting anything in return. His gifts are constant and abundant, reaching every corner of the universe.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/16-Al-Wahhab.mp3"
  },
  {
    id: 17,
    name: "Ar-Razzaq",
    arabic: "الرزاق",
    meaning: "The Provider",
    description: "The One who provides sustenance for all His creatures. He knows the needs of every living being and ensures that they are met in due time.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/17-Ar-Razzaq.mp3"
  },
  {
    id: 18,
    name: "Al-Fattah",
    arabic: "الفتاح",
    meaning: "The Opener",
    description: "The One who opens the doors of mercy, knowledge, and success. He removes obstacles and provides solutions where none seemed to exist.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/18-Al-Fattah.mp3"
  },
  {
    id: 19,
    name: "Al-Alim",
    arabic: "العليم",
    meaning: "The All-Knowing",
    description: "The One whose knowledge encompasses all things, past, present, and future. Nothing is hidden from Him, not even the deepest secrets of the heart.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/19-Al-Alim.mp3"
  },
  {
    id: 20,
    name: "Al-Qabid",
    arabic: "القابض",
    meaning: "The Withholder",
    description: "The One who restricts sustenance or life as He wills. His withholding is always based on wisdom and is a means of testing and growth for the soul.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/20-Al-Qabid.mp3"
  },
  {
    id: 21,
    name: "Al-Basit",
    arabic: "الباسط",
    meaning: "The Extender",
    description: "The One who expands sustenance and joy for whom He wills. His generosity is limitless, and He brings ease after every hardship.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/21-Al-Basit.mp3"
  },
  {
    id: 22,
    name: "Al-Khafid",
    arabic: "الخافض",
    meaning: "The Abaser",
    description: "The One who humbles the proud and lowers those who are arrogant. He brings justice by elevating the righteous and abasing the wicked.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/22-Al-Khafid.mp3"
  },
  {
    id: 23,
    name: "Ar-Rafi'",
    arabic: "الرافع",
    meaning: "The Exalter",
    description: "The One who elevates the status of His believers and those who are humble. He raises the ranks of those who seek His pleasure.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/23-Ar-Rafi.mp3"
  },
  {
    id: 24,
    name: "Al-Mu'izz",
    arabic: "المعز",
    meaning: "The Bestower of Honor",
    description: "The One who grants dignity and honor to whom He wills. True honor is only found in obedience to Him and seeking His favor.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/24-Al-Muizz.mp3"
  },
  {
    id: 25,
    name: "Al-Mudhill",
    arabic: "المذل",
    meaning: "The Humiliator",
    description: "The One who removes honor from those who are arrogant and disobedient. He shows the reality of those who seek glory outside of His path.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/25-Al-Mudhill.mp3"
  },
  {
    id: 26,
    name: "As-Sami'",
    arabic: "السميع",
    meaning: "The All-Hearing",
    description: "The One who hears every sound, every whisper, and every silent prayer. He is always listening to the calls of His servants.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/26-As-Sami.mp3"
  },
  {
    id: 27,
    name: "Al-Basir",
    arabic: "البصير",
    meaning: "The All-Seeing",
    description: "The One who sees all things, even the movement of a black ant on a black stone in the middle of a dark night. Nothing is hidden from His sight.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/27-Al-Basir.mp3"
  },
  {
    id: 28,
    name: "Al-Hakam",
    arabic: "الحكم",
    meaning: "The Judge",
    description: "The One whose judgment is final and just. He is the ultimate arbiter who decides between truth and falsehood.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/28-Al-Hakam.mp3"
  },
  {
    id: 29,
    name: "Al-Adl",
    arabic: "العدل",
    meaning: "The Just",
    description: "The One who is perfectly just in all His actions and decrees. He never wrongs anyone and ensures that every soul receives what it deserves.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/29-Al-Adl.mp3"
  },
  {
    id: 30,
    name: "Al-Latif",
    arabic: "اللطيف",
    meaning: "The Subtle One",
    description: "The One who is kind and gentle in His dealings. He provides for His servants in ways they cannot perceive and is aware of the most delicate details.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/30-Al-Latif.mp3"
  },
  {
    id: 31,
    name: "Al-Khabir",
    arabic: "الخبير",
    meaning: "The All-Aware",
    description: "The One who is aware of the inner reality of all things. He knows the hidden intentions and the true nature of every action.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/31-Al-Khabir.mp3"
  },
  {
    id: 32,
    name: "Al-Halim",
    arabic: "الحليم",
    meaning: "The Forbearing",
    description: "The One who is patient and does not hasten to punish. He gives His servants time to repent and return to Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/32-Al-Halim.mp3"
  },
  {
    id: 33,
    name: "Al-Azim",
    arabic: "العظيم",
    meaning: "The Magnificent",
    description: "The One whose greatness is beyond all limits. He is the most magnificent in His essence, attributes, and actions.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/33-Al-Azim.mp3"
  },
  {
    id: 34,
    name: "Al-Ghafur",
    arabic: "الغفور",
    meaning: "The All-Forgiving",
    description: "The One who forgives all sins, no matter how great they may be. His mercy is vast and His forgiveness is complete.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/34-Al-Ghafur.mp3"
  },
  {
    id: 35,
    name: "Ash-Shakur",
    arabic: "الشكور",
    meaning: "The Appreciative",
    description: "The One who rewards even the smallest good deed with abundant blessings. He is appreciative of the efforts of His servants.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/35-Ash-Shakur.mp3"
  },
  {
    id: 36,
    name: "Al-Aliyy",
    arabic: "العلي",
    meaning: "The Most High",
    description: "The One who is high above all creation. His status and power are supreme, and nothing can reach His level.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/36-Al-Ali.mp3"
  },
  {
    id: 37,
    name: "Al-Kabir",
    arabic: "الكبير",
    meaning: "The Most Great",
    description: "The One who is the greatest in every sense. His greatness is eternal and unchanging, encompassing all of existence.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/37-Al-Kabir.mp3"
  },
  {
    id: 38,
    name: "Al-Hafiz",
    arabic: "الحفيظ",
    meaning: "The Preserver",
    description: "The One who preserves and protects all things. He keeps the universe in balance and guards His servants from harm.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/38-Al-Hafiz.mp3"
  },
  {
    id: 39,
    name: "Al-Muqit",
    arabic: "المقيت",
    meaning: "The Nourisher",
    description: "The One who provides nourishment for both the body and the soul. He is the source of all strength and sustenance.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/39-Al-Muqit.mp3"
  },
  {
    id: 40,
    name: "Al-Hasib",
    arabic: "الحسيب",
    meaning: "The Reckoner",
    description: "The One who takes account of all things. He is sufficient as a protector and a judge for His servants.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/40-Al-Hasib.mp3"
  },
  {
    id: 41,
    name: "Al-Jalil",
    arabic: "الجليل",
    meaning: "The Majestic",
    description: "The One who is majestic in His attributes and actions. His glory is evident in every part of the creation.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/41-Al-Jalil.mp3"
  },
  {
    id: 42,
    name: "Al-Karim",
    arabic: "الكريم",
    meaning: "The Generous",
    description: "The One who is most generous and kind. He gives without being asked and His generosity knows no bounds.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/42-Al-Karim.mp3"
  },
  {
    id: 43,
    name: "Ar-Raqib",
    arabic: "الرقيب",
    meaning: "The Watchful",
    description: "The One who is always watching over His creation. Nothing escapes His gaze, and He is aware of every movement.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/43-Ar-Raqib.mp3"
  },
  {
    id: 44,
    name: "Al-Mujib",
    arabic: "المجيب",
    meaning: "The Responsive",
    description: "The One who responds to the prayers and calls of His servants. He is always near and ready to answer those who seek Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/44-Al-Mujib.mp3"
  },
  {
    id: 45,
    name: "Al-Wasi'",
    arabic: "الواسع",
    meaning: "The All-Encompassing",
    description: "The One whose mercy and knowledge encompass all things. His kingdom is vast and His blessings are limitless.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/45-Al-Wasi.mp3"
  },
  {
    id: 46,
    name: "Al-Hakim",
    arabic: "الحكيم",
    meaning: "The Wise",
    description: "The One who is perfectly wise in all His actions and decrees. Everything He does is based on infinite wisdom and purpose.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/46-Al-Hakim.mp3"
  },
  {
    id: 47,
    name: "Al-Wadud",
    arabic: "الودود",
    meaning: "The Most Loving",
    description: "The One who is the source of all love and affection. He loves His righteous servants and is the most beloved to them.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/47-Al-Wadud.mp3"
  },
  {
    id: 48,
    name: "Al-Majid",
    arabic: "المجيد",
    meaning: "The Glorious",
    description: "The One who is most glorious and honorable. His glory is eternal and His majesty is beyond description.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/48-Al-Majid.mp3"
  },
  {
    id: 49,
    name: "Al-Ba'ith",
    arabic: "الباعث",
    meaning: "The Resurrector",
    description: "The One who will bring the dead back to life on the Day of Judgment. He is the source of all life and the one who restores it.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/49-Al-Baith.mp3"
  },
  {
    id: 50,
    name: "Ash-Shahid",
    arabic: "الشهيد",
    meaning: "The Witness",
    description: "The One who witnesses all things. He is present everywhere and nothing is hidden from His sight or knowledge.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/50-Ash-Shahid.mp3"
  },
  {
    id: 51,
    name: "Al-Haqq",
    arabic: "الحق",
    meaning: "The Truth",
    description: "The One who is the absolute truth. His existence is real and His word is the ultimate reality.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/51-Al-Haqq.mp3"
  },
  {
    id: 52,
    name: "Al-Wakil",
    arabic: "الوكيل",
    meaning: "The Trustee",
    description: "The One who is the best disposer of affairs. He is sufficient as a protector and a guide for those who trust in Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/52-Al-Wakil.mp3"
  },
  {
    id: 53,
    name: "Al-Qawiyy",
    arabic: "القوي",
    meaning: "The Strong",
    description: "The One whose power is absolute and whose strength is limitless. Nothing can overcome His might.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/53-Al-Qawiyy.mp3"
  },
  {
    id: 54,
    name: "Al-Matin",
    arabic: "المتين",
    meaning: "The Firm",
    description: "The One who is firm in His power and strength. His authority is unchanging and His decree is final.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/54-Al-Matin.mp3"
  },
  {
    id: 55,
    name: "Al-Waliyy",
    arabic: "الولي",
    meaning: "The Protecting Friend",
    description: "The One who is the friend and protector of the believers. He guides them and helps them in every situation.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/55-Al-Wali.mp3"
  },
  {
    id: 56,
    name: "Al-Hamid",
    arabic: "الحميد",
    meaning: "The Praiseworthy",
    description: "The One who is worthy of all praise. His attributes and actions are perfect, and He is praised by all of creation.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/56-Al-Hamid.mp3"
  },
  {
    id: 57,
    name: "Al-Muhsi",
    arabic: "المحصي",
    meaning: "The Counter",
    description: "The One who counts and records all things. Nothing escapes His knowledge, and He keeps a perfect record of every action.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/57-Al-Muhsi.mp3"
  },
  {
    id: 58,
    name: "Al-Mubdi'",
    arabic: "المبدئ",
    meaning: "The Originator",
    description: "The One who begins the creation. He is the source of all existence and the one who brings things into being.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/58-Al-Mubdi.mp3"
  },
  {
    id: 59,
    name: "Al-Mu'id",
    arabic: "المعيد",
    meaning: "The Restorer",
    description: "The One who restores the creation after it has passed away. He will bring everything back to life on the Day of Judgment.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/59-Al-Muid.mp3"
  },
  {
    id: 60,
    name: "Al-Muhyi",
    arabic: "المحيي",
    meaning: "The Giver of Life",
    description: "The One who gives life to the dead. He is the source of all vitality and the one who sustains it.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/60-Al-Muhyi.mp3"
  },
  {
    id: 61,
    name: "Al-Mumit",
    arabic: "المميت",
    meaning: "The Bringer of Death",
    description: "The One who ordains death for all living beings. He is the one who takes life away when the appointed time comes.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/61-Al-Mumit.mp3"
  },
  {
    id: 62,
    name: "Al-Hayy",
    arabic: "الحي",
    meaning: "The Ever-Living",
    description: "The One who is eternally alive. His life is self-sustaining and has no beginning or end.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/62-Al-Hayy.mp3"
  },
  {
    id: 63,
    name: "Al-Qayyum",
    arabic: "القيوم",
    meaning: "The Self-Sustaining",
    description: "The One who sustains Himself and all of creation. He is the foundation of all existence and nothing can exist without Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/63-Al-Qayyum.mp3"
  },
  {
    id: 64,
    name: "Al-Wajid",
    arabic: "الواجد",
    meaning: "The Perceiver",
    description: "The One who finds and perceives all things. Nothing is hidden from Him, and He is aware of everything in the universe.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/64-Al-Wajid.mp3"
  },
  {
    id: 65,
    name: "Al-Majid",
    arabic: "الماجد",
    meaning: "The Illustrious",
    description: "The One who is illustrious and honorable. His glory is evident in every part of the creation.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/65-Al-Majid.mp3"
  },
  {
    id: 66,
    name: "Al-Wahid",
    arabic: "الواحد",
    meaning: "The One",
    description: "The One who is unique and has no partner. He is the only true God and there is none like Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/66-Al-Wahid.mp3"
  },
  {
    id: 67,
    name: "Al-Ahad",
    arabic: "الأحد",
    meaning: "The Unique",
    description: "The One who is indivisible and unique in His essence. He is far above any resemblance to His creation.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/67-Al-Ahad.mp3"
  },
  {
    id: 68,
    name: "As-Samad",
    arabic: "الصمد",
    meaning: "The Eternal",
    description: "The One who is eternal and self-sufficient. All of creation depends on Him, while He depends on no one.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/68-As-Samad.mp3"
  },
  {
    id: 69,
    name: "Al-Qadir",
    arabic: "القادر",
    meaning: "The Capable",
    description: "The One who is capable of all things. His power is absolute and His will is always executed.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/69-Al-Qadir.mp3"
  },
  {
    id: 70,
    name: "Al-Muqtadir",
    arabic: "المقتدر",
    meaning: "The All-Powerful",
    description: "The One whose power is supreme and encompassing. He is the ultimate authority in the universe.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/70-Al-Muqtadir.mp3"
  },
  {
    id: 71,
    name: "Al-Muqaddim",
    arabic: "المقدم",
    meaning: "The Expediter",
    description: "The One who brings things forward as He wills. He decides the timing of every event in the universe.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/71-Al-Muqaddim.mp3"
  },
  {
    id: 72,
    name: "Al-Mu'akhkhir",
    arabic: "المؤخر",
    meaning: "The Delayer",
    description: "The One who delays things as He wills. His timing is always based on infinite wisdom and purpose.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/72-Al-Muakhkhir.mp3"
  },
  {
    id: 73,
    name: "Al-Awwal",
    arabic: "الأول",
    meaning: "The First",
    description: "The One who existed before anything else. He has no beginning and is the source of all existence.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/73-Al-Awwal.mp3"
  },
  {
    id: 74,
    name: "Al-Akhir",
    arabic: "الآخر",
    meaning: "The Last",
    description: "The One who will exist after everything else has passed away. He has no end and is the ultimate destination of all things.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/74-Al-Akhir.mp3"
  },
  {
    id: 75,
    name: "Az-Zahir",
    arabic: "الظاهر",
    meaning: "The Manifest",
    description: "The One whose existence is evident in every part of the creation. His signs are everywhere for those who seek Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/75-Az-Zahir.mp3"
  },
  {
    id: 76,
    name: "Al-Batin",
    arabic: "الباطن",
    meaning: "The Hidden",
    description: "The One who is hidden from human perception. His essence is beyond comprehension, but His presence is felt everywhere.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/76-Al-Batin.mp3"
  },
  {
    id: 77,
    name: "Al-Wali",
    arabic: "الوالي",
    meaning: "The Governor",
    description: "The One who manages and governs all affairs. He is the ultimate authority who ensures that everything runs according to His plan.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/77-Al-Wali.mp3"
  },
  {
    id: 78,
    name: "Al-Muta'ali",
    arabic: "المتعالي",
    meaning: "The Most Exalted",
    description: "The One who is high above all creation. His status and power are supreme, and nothing can reach His level.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/78-Al-Mutaali.mp3"
  },
  {
    id: 79,
    name: "Al-Barr",
    arabic: "البر",
    meaning: "The Source of Goodness",
    description: "The One who is the source of all goodness and kindness. He is most generous to His servants and His blessings are constant.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/79-Al-Barr.mp3"
  },
  {
    id: 80,
    name: "At-Tawwab",
    arabic: "التواب",
    meaning: "The Ever-Relenting",
    description: "The One who repeatedly accepts the repentance of His servants. He is always ready to forgive those who return to Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/80-At-Tawwab.mp3"
  },
  {
    id: 81,
    name: "Al-Muntaqim",
    arabic: "المنتقم",
    meaning: "The Avenger",
    description: "The One who brings justice by punishing the wicked and the arrogant. His punishment is just and based on infinite wisdom.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/81-Al-Muntaqim.mp3"
  },
  {
    id: 82,
    name: "Al-Afuww",
    arabic: "العفو",
    meaning: "The Pardoner",
    description: "The One who pardons sins and removes their traces. His mercy is vast and His forgiveness is complete.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/82-Al-Afuww.mp3"
  },
  {
    id: 83,
    name: "Ar-Ra'uf",
    arabic: "الرؤوف",
    meaning: "The Most Kind",
    description: "The One who is most kind and compassionate. His mercy is gentle and His care for His servants is infinite.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/83-Ar-Rauf.mp3"
  },
  {
    id: 84,
    name: "Malik-ul-Mulk",
    arabic: "مالك الملك",
    meaning: "The Owner of Sovereignty",
    description: "The One who is the absolute owner of all sovereignty. He manages the universe with perfect wisdom and authority.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/84-Malik-ul-Mulk.mp3"
  },
  {
    id: 85,
    name: "Dhul-Jalal wal-Ikram",
    arabic: "ذو الجلال والإكرام",
    meaning: "The Lord of Majesty and Generosity",
    description: "The One who is the source of all majesty and generosity. He is worthy of all honor and His blessings are limitless.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/85-Dhul-Jalal-wal-Ikram.mp3"
  },
  {
    id: 86,
    name: "Al-Muqsit",
    arabic: "المقسط",
    meaning: "The Equitable",
    description: "The One who is perfectly equitable and just. He ensures that every soul receives what it deserves and never wrongs anyone.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/86-Al-Muqsit.mp3"
  },
  {
    id: 87,
    name: "Al-Jami'",
    arabic: "الجامع",
    meaning: "The Gatherer",
    description: "The One who will gather all of creation on the Day of Judgment. He brings together what was scattered and ensures that justice is served.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/87-Al-Jami.mp3"
  },
  {
    id: 88,
    name: "Al-Ghaniyy",
    arabic: "الغني",
    meaning: "The Self-Sufficient",
    description: "The One who is self-sufficient and depends on no one. All of creation depends on Him, while He is free from all needs.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/88-Al-Ghani.mp3"
  },
  {
    id: 89,
    name: "Al-Mughni",
    arabic: "المغني",
    meaning: "The Enricher",
    description: "The One who enriches His servants with both material and spiritual wealth. He provides for them in ways they cannot perceive.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/89-Al-Mughni.mp3"
  },
  {
    id: 90,
    name: "Al-Mani'",
    arabic: "المانع",
    meaning: "The Withholder",
    description: "The One who prevents harm and withholds sustenance as He wills. His withholding is always based on wisdom and purpose.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/90-Al-Mani.mp3"
  },
  {
    id: 91,
    name: "Ad-Darr",
    arabic: "الضار",
    meaning: "The Distresser",
    description: "The One who ordains distress and hardship as a means of testing and growth. He is the only one who can remove it.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/91-Ad-Darr.mp3"
  },
  {
    id: 92,
    name: "An-Nafi'",
    arabic: "النافع",
    meaning: "The Propitious",
    description: "The One who is the source of all benefit and goodness. He provides for His servants and His blessings are constant.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/92-An-Nafi.mp3"
  },
  {
    id: 93,
    name: "An-Nur",
    arabic: "النور",
    meaning: "The Light",
    description: "The One who is the source of all light and guidance. He illuminates the hearts of the believers and guides them to the truth.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/93-An-Nur.mp3"
  },
  {
    id: 94,
    name: "Al-Hadi",
    arabic: "الهادي",
    meaning: "The Guide",
    description: "The One who guides His servants to the straight path. He provides them with the knowledge and strength to follow His path.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/94-Al-Hadi.mp3"
  },
  {
    id: 95,
    name: "Al-Badi'",
    arabic: "البديع",
    meaning: "The Incomparable",
    description: "The One who creates without a pre-existing model. He is the source of all innovation and His creation is unique.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/95-Al-Badi.mp3"
  },
  {
    id: 96,
    name: "Al-Baqi",
    arabic: "الباقي",
    meaning: "The Everlasting",
    description: "The One who will exist forever. He has no end and His existence is self-sustaining and eternal.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/96-Al-Baqi.mp3"
  },
  {
    id: 97,
    name: "Al-Warith",
    arabic: "الوارث",
    meaning: "The Inheritor",
    description: "The One who will inherit everything after it has passed away. He is the ultimate owner of all that exists.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/97-Al-Warith.mp3"
  },
  {
    id: 98,
    name: "Ar-Rashid",
    arabic: "الرشيد",
    meaning: "The Guide to the Right Path",
    description: "The One who guides His servants to the straight path with perfect wisdom. He provides them with the knowledge and strength to follow His path.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/98-Ar-Rashid.mp3"
  },
  {
    id: 99,
    name: "As-Sabur",
    arabic: "الصبور",
    meaning: "The Patient",
    description: "The One who is most patient and does not hasten to punish. He gives His servants time to repent and return to Him.",
    audio: "https://www.islamic-relief.org.uk/wp-content/uploads/2021/05/99-As-Sabur.mp3"
  }
];
