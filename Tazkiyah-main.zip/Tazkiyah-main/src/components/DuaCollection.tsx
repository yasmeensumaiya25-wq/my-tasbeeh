import { motion } from "motion/react";
import { Heart, Search, BookOpen } from "lucide-react";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const duas = [
  {
    category: "Morning",
    arabic: "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
    translation: "O Allah, by You we enter the morning and by You we enter the evening, by You we live and by You we die, and to You is the Final Return.",
    source: "Abu Dawud"
  },
  {
    category: "Forgiveness",
    arabic: "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي",
    translation: "O Allah, You are Forgiving and love forgiveness, so forgive me.",
    source: "Tirmidhi"
  },
  {
    category: "Protection",
    arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
    translation: "In the Name of Allah with Whose Name nothing can cause harm in the earth nor in the heavens, and He is the All-Hearing, the All-Knowing.",
    source: "Abu Dawud"
  },
  {
    category: "Anxiety",
    arabic: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ",
    translation: "O Allah, I seek refuge in You from anxiety and sorrow, weakness and laziness, miserliness and cowardice.",
    source: "Bukhari"
  }
];

export const DuaCollection = () => {
  const [filter, setFilter] = useState("All");
  const categories = ["All", ...new Set(duas.map(d => d.category))];

  const filteredDuas = filter === "All" ? duas : duas.filter(d => d.category === filter);

  return (
    <section id="duas" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <BookOpen className="w-3 h-3" />
            Supplications
          </motion.div>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-4">Dua Collection</h2>
          <p className="text-slate-600 dark:text-slate-400">A collection of authentic supplications for every moment of your life.</p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map(cat => (
            <Button
              key={cat}
              variant={filter === cat ? "default" : "outline"}
              onClick={() => setFilter(cat)}
              className={`rounded-full px-6 transition-all ${
                filter === cat ? "bg-emerald-600 text-white" : "border-emerald-100 dark:border-emerald-900 text-emerald-600"
              }`}
            >
              {cat}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredDuas.map((dua, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full border-none bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm hover:shadow-xl transition-all duration-500">
                <CardContent className="p-8">
                  <div className="flex justify-between items-start mb-6">
                    <Badge variant="outline" className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 border-none">
                      {dua.category}
                    </Badge>
                    <Heart className="w-4 h-4 text-emerald-600/30" />
                  </div>
                  <p className="text-2xl font-arabic text-right mb-6 text-emerald-900 dark:text-emerald-50 leading-loose">
                    {dua.arabic}
                  </p>
                  <p className="text-slate-600 dark:text-slate-300 italic mb-4">
                    {dua.translation}
                  </p>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                    Source: {dua.source}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
