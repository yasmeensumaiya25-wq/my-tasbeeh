import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Heart, Wind, Sun, Moon, Cloud, Star, Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface Ayah {
  text: string;
  translation: string;
  reference: string;
}

const ayahData: Record<string, Ayah[]> = {
  Sad: [
    {
      text: "لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا",
      translation: "Do not grieve; indeed Allah is with us.",
      reference: "Surah At-Tawbah 9:40"
    },
    {
      text: "إِنَّ مَعَ الْعُسْرِ يُسْرًا",
      translation: "Indeed, with hardship [will be] ease.",
      reference: "Surah Ash-Sharh 94:6"
    }
  ],
  Anxious: [
    {
      text: "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ",
      translation: "Unquestionably, by the remembrance of Allah hearts are assured.",
      reference: "Surah Ar-Ra'd 13:28"
    },
    {
      text: "وَتَوَكَّلْ عَلَى اللَّهِ ۚ وَكَفَىٰ بِاللَّهِ وَكِيلًا",
      translation: "And rely upon Allah; and sufficient is Allah as Disposer of affairs.",
      reference: "Surah Al-Ahzab 33:3"
    }
  ],
  Happy: [
    {
      text: "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ",
      translation: "So which of the favors of your Lord would you deny?",
      reference: "Surah Ar-Rahman 55:13"
    },
    {
      text: "وَآتَاكُم مِّن كُلِّ مَا سَأَلْتُمُوهُ",
      translation: "And He gave you from all you asked of Him.",
      reference: "Surah Ibrahim 14:34"
    }
  ],
  Grateful: [
    {
      text: "لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ",
      translation: "If you are grateful, I will surely increase you [in favor].",
      reference: "Surah Ibrahim 14:7"
    },
    {
      text: "وَكَانَ فَضْلُ اللَّهِ عَلَيْكَ عَظِيمًا",
      translation: "And ever has the favor of Allah upon you been great.",
      reference: "Surah An-Nisa 4:113"
    }
  ],
  Weak: [
    {
      text: "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا",
      translation: "Allah does not charge a soul except [with that within] its capacity.",
      reference: "Surah Al-Baqarah 2:286"
    },
    {
      text: "وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ",
      translation: "And seek help through patience and prayer.",
      reference: "Surah Al-Baqarah 2:45"
    }
  ],
  Lonely: [
    {
      text: "وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ",
      translation: "And He is with you wherever you are.",
      reference: "Surah Al-Hadid 57:4"
    },
    {
      text: "وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ",
      translation: "And We are closer to him than [his] jugular vein.",
      reference: "Surah Qaf 50:16"
    }
  ]
};

const emotions = [
  { name: "Sad", icon: Cloud, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-900/20" },
  { name: "Anxious", icon: Wind, color: "text-indigo-500", bg: "bg-indigo-50 dark:bg-indigo-900/20" },
  { name: "Happy", icon: Sun, color: "text-amber-500", bg: "bg-amber-50 dark:bg-amber-900/20" },
  { name: "Grateful", icon: Heart, color: "text-rose-500", bg: "bg-rose-50 dark:bg-rose-900/20" },
  { name: "Weak", icon: Moon, color: "text-slate-500", bg: "bg-slate-50 dark:bg-slate-900/20" },
  { name: "Lonely", icon: Star, color: "text-emerald-500", bg: "bg-emerald-50 dark:bg-emerald-900/20" },
];

export const AyahJar = () => {
  const [selectedEmotion, setSelectedEmotion] = useState<string | null>(null);
  const [currentAyah, setCurrentAyah] = useState<Ayah | null>(null);
  const [isJiggling, setIsJiggling] = useState(false);

  const pickAyah = (emotion: string) => {
    setIsJiggling(true);
    setTimeout(() => {
      const ayahs = ayahData[emotion];
      const randomAyah = ayahs[Math.floor(Math.random() * ayahs.length)];
      setSelectedEmotion(emotion);
      setCurrentAyah(randomAyah);
      setIsJiggling(false);
    }, 600);
  };

  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3 h-3" />
            Spiritual Motivation
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-4"
          >
            The Ayah Jar
          </motion.h2>
          <p className="text-slate-600 dark:text-slate-400">
            How are you feeling today? Pick an emotion to find a random Ayah that speaks to your heart.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
          {emotions.map((emotion) => (
            <motion.button
              key={emotion.name}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => pickAyah(emotion.name)}
              className={`p-4 rounded-2xl flex flex-col items-center gap-3 transition-all duration-300 ${
                selectedEmotion === emotion.name 
                  ? "ring-2 ring-amber-400 shadow-lg shadow-amber-200/20" 
                  : "hover:shadow-md"
              } ${emotion.bg}`}
            >
              <emotion.icon className={`w-6 h-6 ${emotion.color}`} />
              <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{emotion.name}</span>
            </motion.button>
          ))}
        </div>

        <div className="relative flex justify-center items-center py-12">
          {/* Jar Illustration */}
          <motion.div
            animate={isJiggling ? {
              rotate: [-2, 2, -2, 2, 0],
              x: [-2, 2, -2, 2, 0]
            } : {}}
            transition={{ duration: 0.5, repeat: isJiggling ? Infinity : 0 }}
            className="relative w-48 h-64 bg-white/40 dark:bg-slate-800/40 backdrop-blur-xl border-4 border-white/60 dark:border-slate-700/60 rounded-t-[4rem] rounded-b-[2rem] shadow-2xl flex flex-col items-center justify-center overflow-hidden group"
          >
            <div className="absolute top-0 w-full h-8 bg-white/80 dark:bg-slate-700/80 border-b-2 border-white/20" />
            <div className="absolute top-2 w-12 h-1 bg-slate-200 dark:bg-slate-600 rounded-full" />
            
            <AnimatePresence mode="wait">
              {!currentAyah ? (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center gap-4 text-slate-400 dark:text-slate-500"
                >
                  <Quote className="w-12 h-12 opacity-20" />
                  <p className="text-xs font-bold uppercase tracking-widest text-center px-4">
                    Pick an emotion to fill the jar
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="full"
                  initial={{ y: 50, opacity: 0, scale: 0.5 }}
                  animate={{ y: 0, opacity: 1, scale: 1 }}
                  className="flex flex-col items-center gap-2"
                >
                  <div className="w-12 h-16 bg-amber-100 dark:bg-amber-900/40 rounded-lg border-2 border-amber-200 dark:border-amber-800 shadow-inner flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-amber-500" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Floating sparkles inside jar */}
            <div className="absolute inset-0 pointer-events-none">
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{
                    y: [-20, 20, -20],
                    opacity: [0.2, 0.5, 0.2],
                  }}
                  transition={{
                    duration: 2 + Math.random() * 2,
                    repeat: Infinity,
                    delay: Math.random() * 2,
                  }}
                  className="absolute w-1 h-1 bg-amber-400 rounded-full"
                  style={{
                    top: `${20 + Math.random() * 60}%`,
                    left: `${20 + Math.random() * 60}%`,
                  }}
                />
              ))}
            </div>
          </motion.div>

          {/* Ayah Display Card */}
          <AnimatePresence>
            {currentAyah && !isJiggling && (
              <motion.div
                initial={{ opacity: 0, x: 50, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 50, scale: 0.9 }}
                className="absolute left-[60%] md:left-[55%] w-full max-w-sm z-10"
              >
                <Card className="border-none bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl shadow-2xl shadow-amber-900/10 overflow-hidden">
                  <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 to-rose-400" />
                  <CardContent className="p-8">
                    <div className="mb-6">
                      <p className="text-right text-2xl font-arabic leading-loose text-slate-900 dark:text-white mb-4">
                        {currentAyah.text}
                      </p>
                      <p className="text-slate-600 dark:text-slate-400 italic leading-relaxed">
                        "{currentAyah.translation}"
                      </p>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest">
                        {currentAyah.reference}
                      </span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs h-8"
                        onClick={() => pickAyah(selectedEmotion!)}
                      >
                        Another one
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};
