import { motion } from "motion/react";
import { Sparkles, Heart, Shield, Sun, Moon, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const beautyAspects = [
  {
    title: "Divine Mercy",
    description: "Islam teaches that God's mercy precedes His wrath. It is a religion of hope, where every sincere repentance is met with open arms.",
    icon: Heart,
    color: "text-rose-500",
    bg: "bg-rose-50 dark:bg-rose-900/20"
  },
  {
    title: "Universal Equality",
    description: "In the eyes of the Creator, no race is superior to another. Excellence is measured only by character and devotion.",
    icon: Sparkles,
    color: "text-amber-500",
    bg: "bg-amber-50 dark:bg-amber-900/20"
  },
  {
    title: "Inner Peace",
    description: "Through prayer and remembrance, the heart finds a tranquility that the world cannot provide or take away.",
    icon: Shield,
    color: "text-emerald-500",
    bg: "bg-emerald-50 dark:bg-emerald-900/20"
  },
  {
    title: "Intellectual Growth",
    description: "The first word revealed was 'Read'. Islam encourages the pursuit of knowledge as a form of worship.",
    icon: Star,
    color: "text-blue-500",
    bg: "bg-blue-50 dark:bg-blue-900/20"
  }
];

export const BeautyOfIslam = () => {
  return (
    <section id="beauty" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* ... existing header ... */}
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3 h-3" />
            The Essence
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white mb-6">
            The Beauty of Islam
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto text-lg">
            Discover the profound wisdom, compassion, and light that Islam brings to the human experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {beautyAspects.map((aspect, index) => (
            <motion.div
              key={aspect.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full border-none bg-white/40 dark:bg-slate-900/40 backdrop-blur-md hover:bg-white/60 dark:hover:bg-slate-900/60 transition-all duration-500 group">
                <CardContent className="p-8">
                  <div className={`w-14 h-14 rounded-2xl ${aspect.bg} ${aspect.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <aspect.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-white mb-4">
                    {aspect.title}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {aspect.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Quote Section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-24 p-12 rounded-[3rem] bg-emerald-600 text-white text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/islamic-art.png')]" />
          <div className="relative z-10 max-w-3xl mx-auto">
            <Heart className="w-12 h-12 mx-auto mb-8 opacity-50" />
            <p className="text-2xl md:text-3xl font-serif italic mb-8">
              "Islam is a religion of peace, mercy, and compassion. It is a light that guides the soul towards its Creator and towards the service of humanity."
            </p>
            <div className="w-20 h-1 bg-white/30 mx-auto rounded-full" />
          </div>
        </motion.div>
      </div>
    </section>
  );
};
