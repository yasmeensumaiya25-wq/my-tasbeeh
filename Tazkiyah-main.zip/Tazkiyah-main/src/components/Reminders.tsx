import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Bell, CheckCircle2, Clock, Target, Sparkles, ChevronRight, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface Reminder {
  id: string;
  title: string;
  time: string;
  completed: boolean;
  type: "salah" | "goal";
}

export const Reminders = () => {
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const saved = localStorage.getItem("tazkiyah-reminders");
    if (saved) return JSON.parse(saved);
    return [
      { id: "1", title: "Fajr Prayer", time: "05:12 AM", completed: false, type: "salah" },
      { id: "2", title: "Dhuhr Prayer", time: "12:30 PM", completed: false, type: "salah" },
      { id: "3", title: "Asr Prayer", time: "03:45 PM", completed: false, type: "salah" },
      { id: "4", title: "Maghrib Prayer", time: "06:15 PM", completed: false, type: "salah" },
      { id: "5", title: "Isha Prayer", time: "07:45 PM", completed: false, type: "salah" },
      { id: "6", title: "Read 5 Pages of Quran", time: "Daily Goal", completed: false, type: "goal" },
      { id: "7", title: "Morning Adhkar", time: "Daily Goal", completed: false, type: "goal" },
    ];
  });

  const [showNotification, setShowNotification] = useState(false);
  const [activeReminder, setActiveReminder] = useState<Reminder | null>(null);

  useEffect(() => {
    localStorage.setItem("tazkiyah-reminders", JSON.stringify(reminders));
  }, [reminders]);

  const toggleReminder = (id: string) => {
    setReminders(prev => prev.map(r => 
      r.id === id ? { ...r, completed: !r.completed } : r
    ));
  };

  const completedCount = reminders.filter(r => r.completed).length;
  const progress = (completedCount / reminders.length) * 100;

  return (
    <section className="py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row gap-12 items-start">
          <div className="flex-1">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
            >
              <Bell className="w-3 h-3" />
              Daily Check-in
            </motion.div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-6"
            >
              Your Spiritual <br /> Progress
            </motion.h2>
            <p className="text-slate-600 dark:text-slate-400 mb-8 max-w-md">
              Keep track of your daily prayers and spiritual goals. Consistency is the key to a tranquil heart.
            </p>

            <Card className="border-none bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl shadow-2xl shadow-emerald-900/5 overflow-hidden">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-bold text-slate-900 dark:text-white">Daily Completion</span>
                  <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2 bg-emerald-100 dark:bg-emerald-900/30" />
                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-900/10 border border-emerald-100/50 dark:border-emerald-800/50">
                    <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-1">Completed</p>
                    <p className="text-2xl font-serif font-bold text-slate-900 dark:text-white">{completedCount}</p>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50/50 dark:bg-slate-900/10 border border-slate-100/50 dark:border-slate-800/50">
                    <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">Remaining</p>
                    <p className="text-2xl font-serif font-bold text-slate-900 dark:text-white">{reminders.length - completedCount}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex-1 w-full space-y-4">
            <h3 className="text-xl font-serif font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
              <Target className="w-5 h-5 text-emerald-500" />
              Today's Tasks
            </h3>
            
            <div className="space-y-3">
              {reminders.map((reminder, index) => (
                <motion.div
                  key={reminder.id}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <button
                    onClick={() => toggleReminder(reminder.id)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 group ${
                      reminder.completed
                        ? "bg-emerald-50/50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800"
                        : "bg-white/60 dark:bg-slate-900/60 border-slate-100 dark:border-slate-800 hover:border-emerald-200 dark:hover:border-emerald-800"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                        reminder.completed 
                          ? "bg-emerald-500 text-white" 
                          : "bg-slate-100 dark:bg-slate-800 text-slate-400 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900/40 group-hover:text-emerald-500"
                      }`}>
                        {reminder.completed ? <CheckCircle2 className="w-5 h-5" /> : (
                          reminder.type === "salah" ? <Clock className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />
                        )}
                      </div>
                      <div className="text-left">
                        <h4 className={`font-bold text-sm transition-colors ${
                          reminder.completed ? "text-emerald-900 dark:text-emerald-100 line-through opacity-60" : "text-slate-900 dark:text-white"
                        }`}>
                          {reminder.title}
                        </h4>
                        <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                          {reminder.time}
                        </p>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 transition-transform ${
                      reminder.completed ? "text-emerald-500 rotate-90" : "text-slate-300 dark:text-slate-700 group-hover:translate-x-1"
                    }`} />
                  </button>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Notification Simulation */}
      <AnimatePresence>
        {showNotification && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-28 right-6 z-50 w-80"
          >
            <Card className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-emerald-200 dark:border-emerald-800 shadow-2xl">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">Salah Reminder</h5>
                    <p className="text-xs text-slate-500 dark:text-slate-400">It's almost time for Asr prayer. Take a moment for your soul.</p>
                  </div>
                  <button onClick={() => setShowNotification(false)}>
                    <X className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
