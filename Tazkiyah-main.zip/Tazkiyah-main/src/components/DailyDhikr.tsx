import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Sun, Moon, CheckCircle2, RotateCcw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";

const azkarData = {
  morning: [
    { arabic: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", translation: "We have reached the morning and at this very time unto Allah belongs all sovereignty, and all praise is for Allah. None has the right to be worshipped except Allah, alone, without partner...", count: 1 },
    { arabic: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ", translation: "O Allah, You are my Lord, none has the right to be worshipped except You. You created me and I am Your servant...", count: 1 },
    { arabic: "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ", translation: "O Ever Living One, O Self-Sustaining One, in Your mercy I seek relief. Set all my affairs right and do not leave me to myself even for the blink of an eye.", count: 1 },
    { arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ", translation: "Glory be to Allah and His is the praise, (a praise) as many as the number of His creation, and as much as pleases Him...", count: 3 },
    { arabic: "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ", translation: "O Allah, grant me health in my body. O Allah, grant me health in my hearing. O Allah, grant me health in my sight. There is no god but You.", count: 3 },
    { arabic: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", translation: "In the Name of Allah, Who with His Name nothing can cause harm in the earth nor in the heavens, and He is the All-Hearing, the All-Knowing.", count: 3 },
    { arabic: "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيًّا", translation: "I am pleased with Allah as my Lord, with Islam as my religion and with Muhammad (peace and blessings of Allah be upon him) as my Prophet.", count: 3 },
    { arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", translation: "Glory be to Allah and His is the praise.", count: 100 },
  ],
  evening: [
    { arabic: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ", translation: "We have reached the evening and at this very time unto Allah belongs all sovereignty...", count: 1 },
    { arabic: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", translation: "I seek refuge in the perfect words of Allah from the evil of what He has created.", count: 3 },
    { arabic: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ", translation: "O Allah, by You we enter the evening and by You we enter the morning, by You we live and by You we die, and to You is the final return.", count: 1 },
    { arabic: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لَا إِلَهَ إِلَّا أَنْتَ", translation: "O Allah, I seek refuge in You from disbelief and poverty, and I seek refuge in You from the punishment of the grave. There is no god but You.", count: 3 },
    { arabic: "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ", translation: "Allah is sufficient for me. None has the right to be worshipped except Him. In Him I put my trust and He is the Lord of the Mighty Throne.", count: 7 },
  ]
};

export const DailyDhikr = () => {
  const [counts, setCounts] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem("dhikr-counts");
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    const lastReset = localStorage.getItem("dhikr-last-reset");
    const today = new Date().toDateString();
    
    if (lastReset !== today) {
      setCounts({});
      localStorage.setItem("dhikr-last-reset", today);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("dhikr-counts", JSON.stringify(counts));
  }, [counts]);

  const handleCount = (key: string, max: number) => {
    const current = counts[key] || 0;
    if (current < max) {
      // Haptic-like feedback or sound could be added here
      setCounts(prev => ({
        ...prev,
        [key]: current + 1
      }));
    }
  };

  const resetCounts = (type: string) => {
    const newCounts = { ...counts };
    Object.keys(newCounts).forEach(key => {
      if (key.startsWith(type)) {
        delete newCounts[key];
      }
    });
    setCounts(newCounts);
  };

  const getProgress = (type: string) => {
    const items = type === "morning" ? azkarData.morning : azkarData.evening;
    const totalNeeded = items.reduce((acc, item) => acc + item.count, 0);
    const currentTotal = items.reduce((acc, item, i) => {
      const key = `${type}-${i}`;
      return acc + (counts[key] || 0);
    }, 0);
    return (currentTotal / totalNeeded) * 100;
  };

  const renderDhikrList = (items: typeof azkarData.morning, type: string) => {
    const progress = getProgress(type);
    
    return (
      <div className="space-y-6">
        <div className="bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm p-6 rounded-3xl border border-emerald-100/50 dark:border-emerald-900/20">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-bold uppercase tracking-widest text-emerald-600">Daily Progress</h4>
            <span className="text-sm font-bold text-emerald-600">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2 bg-emerald-100 dark:bg-emerald-900/30" />
          <div className="mt-4 flex justify-end">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => resetCounts(type)}
              className="text-xs text-slate-400 hover:text-red-500"
            >
              <RotateCcw className="w-3 h-3 mr-2" /> Reset Session
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {items.map((item, i) => {
            const key = `${type}-${i}`;
            const currentCount = counts[key] || 0;
            const isDone = currentCount >= item.count;

            return (
              <Card key={i} className={`border-none transition-all duration-500 overflow-hidden ${isDone ? "bg-emerald-50/30 dark:bg-emerald-900/5 opacity-60" : "bg-white/60 dark:bg-slate-900/60 hover:shadow-lg hover:shadow-emerald-600/5"}`}>
                <CardContent className="p-6 flex items-center justify-between gap-6">
                  <div className="flex-1">
                    <p className="text-2xl font-arabic text-right mb-4 text-emerald-900 dark:text-emerald-50 leading-loose">
                      {item.arabic}
                    </p>
                    <p className="text-sm text-slate-600 dark:text-slate-400 italic font-serif leading-relaxed">
                      {item.translation}
                    </p>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <Button
                      size="lg"
                      variant={isDone ? "ghost" : "outline"}
                      className={`w-24 h-24 rounded-full border-4 transition-all duration-300 relative group/btn ${
                        isDone 
                          ? "text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500" 
                          : "border-emerald-100 dark:border-emerald-900 text-emerald-600 hover:border-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 active:scale-95"
                      }`}
                      onClick={() => handleCount(key, item.count)}
                    >
                      {/* Progress Ring Simulation */}
                      {!isDone && (
                        <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none">
                          <circle
                            cx="48"
                            cy="48"
                            r="44"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="4"
                            strokeDasharray={276}
                            strokeDashoffset={276 - (276 * currentCount) / item.count}
                            className="transition-all duration-500 ease-out opacity-20"
                          />
                        </svg>
                      )}

                      <AnimatePresence mode="wait">
                        {isDone ? (
                          <motion.div
                            key="done"
                            initial={{ scale: 0.5, opacity: 0, rotate: -45 }}
                            animate={{ scale: 1, opacity: 1, rotate: 0 }}
                            exit={{ scale: 0.5, opacity: 0 }}
                          >
                            <CheckCircle2 className="w-12 h-12" />
                          </motion.div>
                        ) : (
                          <motion.div
                            key={currentCount} // Key change triggers animation on every click
                            initial={{ scale: 0.8, opacity: 0.5 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="flex flex-col items-center"
                          >
                            <span className="text-3xl font-bold font-mono">{currentCount}</span>
                            <span className="text-[10px] uppercase tracking-widest opacity-60 font-bold">/ {item.count}</span>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <section id="dhikr" className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3 h-3" />
            Daily Remembrance
          </motion.div>
          <h2 className="text-4xl font-serif font-bold text-slate-900 dark:text-white mb-4">Daily Azkar</h2>
          <p className="text-slate-600 dark:text-slate-400">Keep your tongue moist with the remembrance of Allah.</p>
        </div>

        <Tabs defaultValue="morning" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8 bg-emerald-50/50 dark:bg-emerald-900/20 p-1 rounded-full">
            <TabsTrigger value="morning" className="rounded-full data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <Sun className="w-4 h-4 mr-2" /> Morning
            </TabsTrigger>
            <TabsTrigger value="evening" className="rounded-full data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <Moon className="w-4 h-4 mr-2" /> Evening
            </TabsTrigger>
          </TabsList>
          <TabsContent value="morning">
            {renderDhikrList(azkarData.morning, "morning")}
          </TabsContent>
          <TabsContent value="evening">
            {renderDhikrList(azkarData.evening, "evening")}
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};
