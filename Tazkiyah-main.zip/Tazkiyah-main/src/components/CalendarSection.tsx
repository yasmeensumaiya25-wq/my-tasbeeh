import { motion } from "motion/react";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from "lucide-react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, isSameMonth, isSameDay, addDays } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toHijri } from "hijri-converter";

export const CalendarSection = () => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const prevMonth = () => setCurrentDate(subMonths(currentDate, 1));

  const renderHeader = () => {
    const hijri = toHijri(currentDate.getFullYear(), currentDate.getMonth() + 1, currentDate.getDate());
    const hijriMonth = getHijriMonthName(hijri.hm);
    
    return (
      <div className="flex items-center justify-between mb-8">
        <div className="flex flex-col">
          <div className="flex items-baseline gap-3">
            <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white">
              {format(currentDate, "MMMM yyyy")}
            </h3>
            <span className="text-slate-300 dark:text-slate-700 font-serif">/</span>
            <span className="text-xl font-serif font-medium text-emerald-600 dark:text-emerald-400">
              {hijriMonth} {hijri.hy} AH
            </span>
          </div>
          <p className="text-xs font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 mt-1">
            Islamic Month: {hijriMonth}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={prevMonth} className="rounded-full">
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={nextMonth} className="rounded-full">
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  };

  const getHijriMonthYear = (date: Date) => {
    const hijri = toHijri(date.getFullYear(), date.getMonth() + 1, date.getDate());
    const hijriMonths = [
      "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
      "Jumada al-Ula", "Jumada al-Akhira", "Rajab", "Sha'ban",
      "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    ];
    return `${hijriMonths[hijri.hm - 1]} ${hijri.hy} AH`;
  };

  const getHijriMonthName = (month: number) => {
    const hijriMonths = [
      "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
      "Jumada al-Ula", "Jumada al-Akhira", "Rajab", "Sha'ban",
      "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    ];
    return hijriMonths[month - 1];
  };

  const renderDays = () => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    return (
      <div className="grid grid-cols-7 mb-4">
        {days.map((day) => (
          <div key={day} className="text-center text-xs font-bold uppercase tracking-wider text-slate-400">
            {day}
          </div>
        ))}
      </div>
    );
  };

  const renderCells = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const rows = [];
    let days = [];
    let day = startDate;
    let formattedDate = "";

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        formattedDate = format(day, "d");
        const cloneDay = day;
        const hijri = toHijri(day.getFullYear(), day.getMonth() + 1, day.getDate());
        
        days.push(
          <div
            key={day.toString()}
            className={`relative h-24 border border-emerald-50/50 dark:border-emerald-900/20 p-2 transition-all duration-300 group ${
              !isSameMonth(day, monthStart)
                ? "bg-slate-50/30 dark:bg-slate-900/10 text-slate-300 dark:text-slate-700"
                : isSameDay(day, new Date())
                ? "bg-emerald-50 dark:bg-emerald-900/30"
                : "bg-white/40 dark:bg-slate-900/40"
            }`}
          >
            <div className="flex justify-between items-start">
              <span className="text-sm font-medium">{formattedDate}</span>
              <span className="text-[10px] font-arabic text-emerald-600 dark:text-emerald-400 opacity-60 group-hover:opacity-100 transition-opacity">
                {hijri.hd}
              </span>
            </div>
            <div className="absolute bottom-2 left-2 text-[8px] font-bold uppercase tracking-tighter text-slate-400 dark:text-slate-500">
              {hijri.hd} {getHijriMonthName(hijri.hm)}
            </div>
            {isSameDay(day, new Date()) && (
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 border border-emerald-500/30 rounded-full" />
            )}
          </div>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div className="grid grid-cols-7" key={day.toString()}>
          {days}
        </div>
      );
      days = [];
    }
    return <div className="rounded-xl overflow-hidden border border-emerald-100 dark:border-emerald-900 shadow-sm">{rows}</div>;
  };

  return (
    <section id="calendar" className="py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <CalendarIcon className="w-3 h-3" />
            Islamic Calendar
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-4"
          >
            Track Your Sacred Days
          </motion.h2>
          <p className="text-slate-600 dark:text-slate-400">
            Stay connected with the Hijri calendar and never miss important Islamic dates.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="border-none bg-white/60 dark:bg-slate-900/60 backdrop-blur-md shadow-2xl shadow-emerald-900/5">
            <CardContent className="p-8">
              {renderHeader()}
              {renderDays()}
              {renderCells()}
            </CardContent>
          </Card>
        </motion.div>
        
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-emerald-50/50 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                <span className="font-bold">15</span>
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Next Event</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">Laylat al-Bara'at</p>
              </div>
            </CardContent>
          </Card>
          {/* Add more info cards if needed */}
        </div>
      </div>
    </section>
  );
};
