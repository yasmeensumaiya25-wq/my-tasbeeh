import { motion } from "motion/react";
import { Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export const QuranQuote = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <Card className="relative overflow-hidden border-none bg-emerald-600 text-white shadow-2xl shadow-emerald-900/20">
            <CardContent className="p-12 text-center relative z-10">
              <Quote className="w-12 h-12 text-emerald-400/50 mx-auto mb-8" />
              <h3 className="text-2xl md:text-3xl font-serif italic leading-relaxed mb-8">
                "So remember Me; I will remember you. And be grateful to Me and do not deny Me."
              </h3>
              <div className="flex flex-col items-center gap-2">
                <div className="h-px w-12 bg-emerald-400" />
                <p className="text-sm font-bold uppercase tracking-widest text-emerald-200">
                  Surah Al-Baqarah 2:152
                </p>
              </div>
            </CardContent>
            
            {/* Decorative background */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-400/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl" />
          </Card>
        </motion.div>
      </div>
    </section>
  );
};
