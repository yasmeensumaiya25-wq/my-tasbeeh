import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Trash2, Calendar, Book, Save, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

interface JournalEntry {
  id: string;
  date: string;
  title: string;
  content: string;
  mood: string;
}

export const JournalSection = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newEntry, setNewEntry] = useState({ title: "", content: "", mood: "Peaceful" });

  useEffect(() => {
    const saved = localStorage.getItem("tazkiyah-journal");
    if (saved) setEntries(JSON.parse(saved));
  }, []);

  const saveEntries = (updated: JournalEntry[]) => {
    setEntries(updated);
    localStorage.setItem("tazkiyah-journal", JSON.stringify(updated));
  };

  const addEntry = () => {
    if (!newEntry.title || !newEntry.content) return;
    const entry: JournalEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      ...newEntry,
    };
    saveEntries([entry, ...entries]);
    setNewEntry({ title: "", content: "", mood: "Peaceful" });
    setIsAdding(false);
  };

  const deleteEntry = (id: string) => {
    saveEntries(entries.filter((e) => e.id !== id));
  };

  return (
    <section id="journal" className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
            >
              <Book className="w-3 h-3" />
              Reflections
            </motion.div>
            <h2 className="text-4xl font-serif font-bold text-slate-900 dark:text-white">Daily Journal</h2>
          </div>
          <Button
            onClick={() => setIsAdding(true)}
            className="rounded-full bg-emerald-600 hover:bg-emerald-700 text-white px-6"
          >
            <Plus className="w-4 h-4 mr-2" /> New Entry
          </Button>
        </div>

        <AnimatePresence>
          {isAdding && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="mb-12"
            >
              <Card className="border-none bg-white/60 dark:bg-slate-900/60 backdrop-blur-md shadow-2xl">
                <CardContent className="p-8 space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-xl font-serif font-bold">What's on your mind?</h3>
                    <Button variant="ghost" size="icon" onClick={() => setIsAdding(false)}>
                      <X className="w-5 h-5" />
                    </Button>
                  </div>
                  <input
                    type="text"
                    placeholder="Entry Title"
                    value={newEntry.title}
                    onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
                    className="w-full bg-emerald-50/50 dark:bg-emerald-900/20 border-none rounded-xl px-4 py-3 text-lg font-serif outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <textarea
                    placeholder="Write your reflections here..."
                    rows={5}
                    value={newEntry.content}
                    onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
                    className="w-full bg-emerald-50/50 dark:bg-emerald-900/20 border-none rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  />
                  <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                      {["Peaceful", "Grateful", "Reflective", "Struggling"].map((m) => (
                        <button
                          key={m}
                          onClick={() => setNewEntry({ ...newEntry, mood: m })}
                          className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                            newEntry.mood === m
                              ? "bg-emerald-600 text-white"
                              : "bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600"
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                    <Button onClick={addEntry} className="bg-emerald-600 text-white rounded-full px-8">
                      <Save className="w-4 h-4 mr-2" /> Save Reflection
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-6">
          {entries.length === 0 ? (
            <div className="text-center py-20 bg-white/20 dark:bg-slate-900/20 rounded-3xl border border-dashed border-emerald-200 dark:border-emerald-800">
              <Book className="w-12 h-12 text-emerald-200 dark:text-emerald-800 mx-auto mb-4" />
              <p className="text-slate-400">No entries yet. Start your journey of reflection today.</p>
            </div>
          ) : (
            entries.map((entry) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                layout
              >
                <Card className="border-none bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm hover:bg-white/60 dark:hover:bg-slate-900/60 transition-all group">
                  <CardContent className="p-8">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600">
                          <Calendar className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                            {format(new Date(entry.date), "MMMM d, yyyy")}
                          </p>
                          <h4 className="text-xl font-serif font-bold text-slate-900 dark:text-white">
                            {entry.title}
                          </h4>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600">
                          {entry.mood}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteEntry(entry.id)}
                          className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {entry.content}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};
