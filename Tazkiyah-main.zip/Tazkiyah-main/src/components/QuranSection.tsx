import { useState, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Book, Search, Play, Pause, Bookmark, ChevronRight, Volume2, X, CheckCircle2, Info, BookOpen as BookIcon, Copy, Share2, Lightbulb, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
  summary?: string;
}

interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  translation?: string;
  tafsir?: string;
  words?: Array<{
    id: number;
    text: string;
    translation: string;
    transliteration: string;
  }>;
}

export const QuranSection = () => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [loadingAyahs, setLoadingAyahs] = useState(false);
  const [isReaderOpen, setIsReaderOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [playingSurah, setPlayingSurah] = useState<number | null>(null);
  const [selectedTafsir, setSelectedTafsir] = useState<number | null>(null);
  const [loadingTafsir, setLoadingTafsir] = useState<number | null>(null);
  const [copiedAyah, setCopiedAyah] = useState<number | null>(null);
  const [showWordByWord, setShowWordByWord] = useState(false);
  const [selectedTranslation, setSelectedTranslation] = useState(131);
  const [showTransliteration, setShowTransliteration] = useState(false);
  const [bookmarks, setBookmarks] = useState<number[]>(() => {
    const saved = localStorage.getItem("quran-bookmarks");
    return saved ? JSON.parse(saved) : [];
  });
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  const [summaryDialogSurah, setSummaryDialogSurah] = useState<Surah | null>(null);
  const [loadingSummary, setLoadingSummary] = useState<number | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ayahAudioRef = useRef<HTMLAudioElement | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const cachedSurahs = localStorage.getItem("quran-surahs-cache");
    if (cachedSurahs) {
      setSurahs(JSON.parse(cachedSurahs));
      setLoading(false);
    }

    fetch("https://api.quran.com/api/v4/chapters?language=en")
      .then((res) => res.json())
      .then((data) => {
        if (!data.chapters) return;
        const mappedSurahs = data.chapters.map((c: any) => ({
          number: c.id,
          name: c.name_arabic,
          englishName: c.name_simple,
          englishNameTranslation: c.translated_name.name,
          numberOfAyahs: c.verses_count,
          revelationType: c.revelation_place,
        }));
        setSurahs(mappedSurahs);
        localStorage.setItem("quran-surahs-cache", JSON.stringify(mappedSurahs));
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        if (!cachedSurahs) setLoading(false);
      });
  }, []);

  const fetchSurahContent = async (surah: Surah, page = 1) => {
    if (page === 1) {
      setSelectedSurah(surah);
      setAyahs([]);
      setIsReaderOpen(true);
      setCurrentPage(1);
      setHasMore(true);
      document.body.style.overflow = "hidden";
    }
    
    setLoadingAyahs(true);

    try {
      // Fetch Surah Info/Summary
      fetch(`https://api.quran.com/api/v4/chapters/${surah.number}/info?language=en`)
        .then(res => res.json())
        .then(data => {
          if (data.chapter_info) {
            setSelectedSurah(prev => prev ? { ...prev, summary: data.chapter_info.short_text } : null);
          }
        });

      const versesRes = await fetch(
        `https://api.quran.com/api/v4/verses/by_chapter/${surah.number}?language=en&words=true&translations=131,20,167,85&fields=text_uthmani&per_page=20&page=${page}`
      );
      const versesData = await versesRes.json();

      const mappedAyahs = versesData.verses?.map((v: any) => {
        // Find the selected translation, or fallback to any available translation
        const translationObj = v.translations?.find((t: any) => t.resource_id === selectedTranslation) 
          || v.translations?.[0];
        
        const translationText = translationObj?.text || "Translation not available";

        return {
          number: v.id,
          text: v.text_uthmani,
          numberInSurah: v.verse_number,
          translation: translationText,
          words: v.words?.map((w: any) => ({
            id: w.id,
            text: w.text_uthmani,
            translation: w.translation.text,
            transliteration: w.transliteration.text,
          })),
        };
      }) || [];

      setAyahs(prev => page === 1 ? mappedAyahs : [...prev, ...mappedAyahs]);
      setHasMore(versesData.pagination.next_page !== null);
      setCurrentPage(page);
      
      if (page === 1 && scrollContainerRef.current) {
        scrollContainerRef.current.scrollTop = 0;
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAyahs(false);
    }
  };

  const fetchTafsir = async (ayahNumberInSurah: number) => {
    if (selectedTafsir === ayahNumberInSurah) {
      setSelectedTafsir(null);
      return;
    }

    setLoadingTafsir(ayahNumberInSurah);
    try {
      const res = await fetch(
        `https://api.quran.com/api/v4/tafsirs/169/by_ayah/${selectedSurah?.number}:${ayahNumberInSurah}`
      );
      const data = await res.json();
      const tafsirText = data.tafsir?.text;
      
      if (!tafsirText) return;

      setAyahs(prev => prev.map(a => 
        a.numberInSurah === ayahNumberInSurah ? { ...a, tafsir: tafsirText } : a
      ));
      setSelectedTafsir(ayahNumberInSurah);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingTafsir(null);
    }
  };

  const copyAyah = (text: string, translation: string, number: number) => {
    const fullText = `${text}\n\n${translation}\n\n[Quran ${selectedSurah?.number}:${number}]`;
    navigator.clipboard.writeText(fullText);
    setCopiedAyah(number);
    setTimeout(() => setCopiedAyah(null), 2000);
  };

  const playAyahAudio = (ayahNumber: number) => {
    if (ayahAudioRef.current) {
      ayahAudioRef.current.pause();
    }
    const audioUrl = `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${ayahNumber}.mp3`;
    const audio = new Audio(audioUrl);
    ayahAudioRef.current = audio;
    audio.play();
  };

  const closeReader = () => {
    setIsReaderOpen(false);
    document.body.style.overflow = "auto";
    setSelectedSurah(null);
    setAyahs([]);
    setSelectedTafsir(null);
  };

  const handlePlayAudio = (surahNumber: number) => {
    if (playingSurah === surahNumber) {
      audioRef.current?.pause();
      setPlayingSurah(null);
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      const audio = new Audio(`https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${surahNumber}.mp3`);
      audioRef.current = audio;
      audio.play();
      setPlayingSurah(surahNumber);
      audio.onended = () => setPlayingSurah(null);
    }
  };

  useEffect(() => {
    localStorage.setItem("quran-bookmarks", JSON.stringify(bookmarks));
  }, [bookmarks]);

  const toggleBookmark = (surahNumber: number) => {
    setBookmarks(prev => 
      prev.includes(surahNumber) 
        ? prev.filter(n => n !== surahNumber) 
        : [...prev, surahNumber]
    );
  };

  const formatToPoints = (html: string) => {
    if (!html) return [];
    const text = html.replace(/<[^>]*>?/gm, '');
    return text
      .split(/[.!?]/)
      .map(s => s.trim())
      .filter(s => s.length > 20);
  };

  const fetchSummaryForDialog = async (surah: Surah) => {
    if (surah.summary) {
      setSummaryDialogSurah(surah);
      return;
    }

    setLoadingSummary(surah.number);
    try {
      const res = await fetch(`https://api.quran.com/api/v4/chapters/${surah.number}/info?language=en`);
      const data = await res.json();
      const summary = data.chapter_info?.short_text || "No summary available.";
      
      const updatedSurah = { ...surah, summary };
      setSurahs(prev => prev.map(s => s.number === surah.number ? updatedSurah : s));
      setSummaryDialogSurah(updatedSurah);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingSummary(null);
    }
  };

  const filteredSurahs = useMemo(() => 
    surahs.filter((s) => {
      const matchesSearch = 
        s.englishName.toLowerCase().includes(search.toLowerCase()) ||
        s.name.includes(search) ||
        s.number.toString() === search;
      
      const matchesBookmark = showBookmarksOnly ? bookmarks.includes(s.number) : true;
      
      return matchesSearch && matchesBookmark;
    }),
    [surahs, search, showBookmarksOnly, bookmarks]
  );

  return (
    <section id="quran" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Book className="w-3 h-3" />
            The Holy Quran
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white mb-6">
            Read & Listen
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto text-lg">
            Access the complete Quran with translations and recitations. A source of guidance for all mankind.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="max-w-2xl mx-auto mb-12 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search Surah by name or number..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white/50 dark:bg-slate-900/50 backdrop-blur-md border border-emerald-100 dark:border-emerald-900 rounded-2xl py-4 pl-12 pr-4 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>
          <Button
            variant={showBookmarksOnly ? "default" : "outline"}
            onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
            className={`rounded-2xl h-auto py-4 px-6 border-emerald-100 dark:border-emerald-900 ${showBookmarksOnly ? "bg-emerald-600 text-white" : "text-emerald-600"}`}
          >
            <Bookmark className={`w-5 h-5 mr-2 ${showBookmarksOnly ? "fill-current" : ""}`} />
            {showBookmarksOnly ? "All Surahs" : "Bookmarks"}
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredSurahs.map((surah, index) => (
                <motion.div
                  key={surah.number}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.02 }}
                >
                  <Card className="group border-none bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm hover:bg-white/60 dark:hover:bg-slate-900/60 transition-all duration-500 hover:shadow-xl">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-4">
                          <div className="relative">
                            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-lg shadow-emerald-600/20">
                              {surah.number}
                            </div>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleBookmark(surah.number);
                              }}
                              className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-white dark:bg-slate-800 shadow-md flex items-center justify-center text-emerald-600 hover:scale-110 transition-transform z-10"
                            >
                              <Bookmark className={`w-3 h-3 ${bookmarks.includes(surah.number) ? "fill-current" : ""}`} />
                            </button>
                          </div>
                          <div>
                            <h3 className="font-serif font-bold text-slate-900 dark:text-white">
                              {surah.englishName}
                            </h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400">
                              {surah.englishNameTranslation}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xl font-arabic text-emerald-600 dark:text-emerald-400">
                            {surah.name}
                          </p>
                          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                            {surah.numberOfAyahs} Ayahs
                          </p>
                        </div>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-4 line-clamp-2 italic">
                        Explore the divine wisdom, historical context, and spiritual guidance contained within this Surah.
                      </p>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1 rounded-xl border-emerald-100 dark:border-emerald-900 text-emerald-600"
                          onClick={() => fetchSurahContent(surah)}
                        >
                          Read Surah
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="rounded-xl border-emerald-100 dark:border-emerald-900 text-emerald-600"
                          onClick={() => fetchSummaryForDialog(surah)}
                          disabled={loadingSummary === surah.number}
                        >
                          {loadingSummary === surah.number ? (
                            <div className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <Lightbulb className="w-4 h-4" />
                          )}
                        </Button>
                        <Button size="sm" 
                          className={`${playingSurah === surah.number ? "bg-red-600 hover:bg-red-700" : "bg-emerald-600 hover:bg-emerald-700"} text-white rounded-xl px-4 transition-colors`}
                          onClick={() => handlePlayAudio(surah.number)}
                        >
                          {playingSurah === surah.number ? <Pause className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        <AnimatePresence>
          {isReaderOpen && (
            <motion.div
              initial={{ opacity: 0, y: "100%" }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-0 z-[100] bg-white dark:bg-slate-950 flex flex-col"
            >
              <div className="bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border-b border-emerald-50 dark:border-emerald-900/50 p-6">
                <div className="max-w-5xl mx-auto flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => selectedSurah && handlePlayAudio(selectedSurah.number)}
                        className={`rounded-xl border-emerald-100 dark:border-emerald-900 ${playingSurah === selectedSurah?.number ? "bg-red-50 text-red-600 border-red-100" : "text-emerald-600"}`}
                      >
                        {playingSurah === selectedSurah?.number ? (
                          <><Pause className="w-4 h-4 mr-2" /> Stop Audio</>
                        ) : (
                          <><Play className="w-4 h-4 mr-2" /> Play Surah</>
                        )}
                      </Button>
                      <div className="flex items-center gap-2">
                        <select 
                          value={selectedTranslation}
                          onChange={(e) => {
                            setSelectedTranslation(Number(e.target.value));
                            if (selectedSurah) fetchSurahContent(selectedSurah, 1);
                          }}
                          className="bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-medium text-emerald-600 outline-none focus:ring-2 focus:ring-emerald-500"
                        >
                          <option value={131}>The Clear Quran</option>
                          <option value={20}>Sahih International</option>
                          <option value={167}>Talal Itani</option>
                          <option value={85}>Muhsin Khan</option>
                        </select>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => setShowWordByWord(!showWordByWord)}
                          className={`rounded-xl border-emerald-100 dark:border-emerald-900 ${showWordByWord ? "bg-emerald-50 text-emerald-600" : "text-slate-500"}`}
                        >
                          {showWordByWord ? "Words" : "Words"}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => setShowTransliteration(!showTransliteration)}
                          className={`rounded-xl border-emerald-100 dark:border-emerald-900 ${showTransliteration ? "bg-emerald-50 text-emerald-600" : "text-slate-500"}`}
                        >
                          {showTransliteration ? "Translit" : "Translit"}
                        </Button>
                      </div>
                      <Button variant="ghost" size="icon" onClick={closeReader} className="rounded-full">
                        <X className="w-6 h-6" />
                      </Button>
                    </div>
                    <div>
                      <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white">
                        {selectedSurah?.englishName}
                      </h3>
                      <p className="text-sm text-emerald-600 dark:text-emerald-400">
                        {selectedSurah?.englishNameTranslation} • {selectedSurah?.numberOfAyahs} Ayahs
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-arabic text-emerald-600 dark:text-emerald-400">
                      {selectedSurah?.name}
                    </p>
                  </div>
                </div>
              </div>

              <div 
                ref={scrollContainerRef}
                className="flex-1 overflow-y-auto bg-slate-50/30 dark:bg-slate-950/30"
              >
                <div className="max-w-4xl mx-auto p-6 md:p-12">
                  {loadingAyahs ? (
                    <div className="flex flex-col items-center justify-center h-96 gap-4">
                      <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                      <p className="text-slate-500 animate-pulse">Loading Surah content...</p>
                    </div>
                  ) : (
                    <div className="space-y-16">
                      {selectedSurah?.summary && currentPage === 1 && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="p-8 rounded-[2rem] bg-emerald-50/50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/20 mb-12"
                        >
                          <div className="flex items-center gap-2 mb-6">
                            <Lightbulb className="w-5 h-5 text-emerald-600" />
                            <h4 className="text-sm font-bold uppercase tracking-widest text-emerald-600">Surah Lessons & Summary</h4>
                          </div>
                          <div className="space-y-4">
                            <ul className="space-y-3">
                              {formatToPoints(selectedSurah.summary).map((point, i) => (
                                <li key={i} className="flex gap-3 text-slate-600 dark:text-slate-400 leading-relaxed">
                                  <div className="mt-2 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                                  <span>{point}.</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </motion.div>
                      )}

                      {selectedSurah?.number !== 1 && selectedSurah?.number !== 9 && (
                        <div className="text-center py-8">
                          <p className="text-5xl font-arabic text-emerald-600 dark:text-emerald-400 opacity-80">
                            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                          </p>
                        </div>
                      )}
                      
                      {ayahs.map((ayah) => (
                        <div key={ayah.number} className="group relative border-b border-emerald-50 dark:border-emerald-900/10 pb-16 last:border-none">
                          <div className="flex flex-col gap-8">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-sm font-bold border border-emerald-100 dark:border-emerald-800">
                                  {ayah.numberInSurah}
                                </div>
                                <div className="flex gap-1">
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => playAyahAudio(ayah.number)}
                                    className="w-8 h-8 rounded-lg text-slate-400 hover:text-emerald-600"
                                  >
                                    <Volume2 className="w-4 h-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => copyAyah(ayah.text, ayah.translation || "", ayah.numberInSurah)}
                                    className="w-8 h-8 rounded-lg text-slate-400 hover:text-emerald-600"
                                    title="Copy Ayah"
                                  >
                                    {copiedAyah === ayah.numberInSurah ? (
                                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                    ) : (
                                      <Copy className="w-4 h-4" />
                                    )}
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    onClick={() => fetchTafsir(ayah.numberInSurah)}
                                    disabled={loadingTafsir === ayah.numberInSurah}
                                    className={`w-10 h-10 rounded-xl transition-all ${selectedTafsir === ayah.numberInSurah ? "text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 ring-2 ring-emerald-500/20" : "text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"}`}
                                    title="View Tafsir"
                                  >
                                    {loadingTafsir === ayah.numberInSurah ? (
                                      <div className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                                    ) : (
                                      <div className="flex flex-col items-center">
                                        <BookIcon className="w-4 h-4" />
                                        <span className="text-[8px] font-bold mt-0.5">TAFSIR</span>
                                      </div>
                                    )}
                                  </Button>
                                </div>
                              </div>
                            </div>
                            <p className="text-4xl md:text-6xl font-arabic text-right leading-[2.2] text-slate-900 dark:text-white mb-4 selection:bg-emerald-100 dark:selection:bg-emerald-900">
                              {ayah.text}
                            </p>

                            {showTransliteration && (
                              <p className="text-emerald-600 dark:text-emerald-400 text-sm font-medium mb-4 italic">
                                {ayah.words?.map(w => w.transliteration).join(" ")}
                              </p>
                            )}

                            {showWordByWord && ayah.words && (
                              <div className="flex flex-wrap flex-row-reverse gap-4 justify-start mb-8">
                                {ayah.words.map((word) => (
                                  <div key={word.id} className="text-center p-3 rounded-xl bg-white dark:bg-slate-900 border border-emerald-50 dark:border-emerald-900/30 hover:border-emerald-200 transition-colors">
                                    <p className="text-2xl font-arabic text-slate-900 dark:text-white mb-1">{word.text}</p>
                                    <p className="text-[10px] text-emerald-600 font-medium mb-0.5">{word.transliteration}</p>
                                    <p className="text-[10px] text-slate-500 dark:text-slate-400">{word.translation}</p>
                                  </div>
                                ))}
                              </div>
                            )}

                            <div className="space-y-6">
                              <div className="p-8 md:p-10 rounded-[2.5rem] bg-emerald-50/60 dark:bg-emerald-900/20 border-l-8 border-emerald-500 shadow-md transition-all hover:shadow-lg group/trans">
                                <div className="flex items-center gap-2 mb-4 opacity-60 group-hover/trans:opacity-100 transition-opacity">
                                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                                  <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600">English Translation</span>
                                </div>
                                <p className="text-slate-800 dark:text-slate-200 text-xl md:text-3xl leading-relaxed font-serif italic">
                                  {ayah.translation?.replace(/<[^>]*>?/gm, '') || "Translation is being loaded or is unavailable..."}
                                </p>
                              </div>
                            </div>
                            
                            <AnimatePresence>
                              {selectedTafsir === ayah.numberInSurah && ayah.tafsir && (
                                <motion.div
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, y: 10 }}
                                  className="overflow-hidden"
                                >
                                  <div className="mt-4 p-8 rounded-3xl bg-emerald-50/30 dark:bg-emerald-900/5 border border-emerald-100/50 dark:border-emerald-900/20">
                                    <div className="flex items-center gap-2 mb-6">
                                      <div className="w-1 h-4 bg-emerald-600 rounded-full" />
                                      <p className="text-xs font-bold uppercase tracking-widest text-emerald-600">Tafsir Ibn Kathir</p>
                                    </div>
                                    <div 
                                      className="text-slate-600 dark:text-slate-400 text-base leading-relaxed prose dark:prose-invert max-w-none prose-p:mb-4 last:prose-p:mb-0"
                                      dangerouslySetInnerHTML={{ __html: ayah.tafsir }}
                                    />
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        </div>
                      ))}

                      {hasMore && (
                        <div className="flex justify-center pt-8">
                          <Button 
                            onClick={() => selectedSurah && fetchSurahContent(selectedSurah, currentPage + 1)}
                            disabled={loadingAyahs}
                            variant="outline"
                            className="rounded-2xl px-8 border-emerald-100 dark:border-emerald-900 text-emerald-600"
                          >
                            {loadingAyahs ? (
                              <div className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin mr-2" />
                            ) : null}
                            Load More Ayahs
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <Dialog open={!!summaryDialogSurah} onOpenChange={() => setSummaryDialogSurah(null)}>
          <DialogContent className="max-w-2xl rounded-[2.5rem] p-0 overflow-hidden border-none bg-white dark:bg-slate-950">
            <div className="relative p-8 md:p-12">
              <div className="absolute top-0 right-0 p-6">
                <Button variant="ghost" size="icon" onClick={() => setSummaryDialogSurah(null)} className="rounded-full">
                  <X className="w-5 h-5" />
                </Button>
              </div>
              
              <div className="mb-8">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-widest mb-4">
                  <Sparkles className="w-3 h-3" />
                  Divine Wisdom
                </div>
                <DialogTitle className="text-3xl md:text-4xl font-serif font-bold text-slate-900 dark:text-white">
                  Surah {summaryDialogSurah?.englishName}
                </DialogTitle>
                <p className="text-emerald-600 font-arabic text-xl mt-2">{summaryDialogSurah?.name}</p>
              </div>

              <ScrollArea className="h-[400px] pr-6">
                <div className="space-y-6">
                  <ul className="space-y-4">
                    {formatToPoints(summaryDialogSurah?.summary || "").map((point, i) => (
                      <motion.li 
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex gap-4 text-slate-600 dark:text-slate-400 text-lg leading-relaxed"
                      >
                        <div className="mt-2.5 w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                        <span>{point}.</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>
              </ScrollArea>

              <div className="mt-12 pt-8 border-t border-emerald-50 dark:border-emerald-900/20 flex justify-end">
                <Button 
                  onClick={() => setSummaryDialogSurah(null)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-8"
                >
                  Close
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
};
