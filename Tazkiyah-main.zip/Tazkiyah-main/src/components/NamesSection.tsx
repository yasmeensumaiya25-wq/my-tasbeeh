import * as React from "react";
import { useState, useMemo, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Pause, Search, Heart, Info, Volume2, VolumeX, Volume1 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { allNames, NameOfAllah } from "../data/names";

export const NamesSection = () => {
  const [search, setSearch] = useState("");
  const [selectedName, setSelectedName] = useState<NameOfAllah | null>(null);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const filteredNames = useMemo(() => {
    return allNames.filter(
      (name) =>
        name.name.toLowerCase().includes(search.toLowerCase()) ||
        name.meaning.toLowerCase().includes(search.toLowerCase()) ||
        name.arabic.includes(search)
    );
  }, [search]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    
    audio.addEventListener("timeupdate", updateTime);
    audio.addEventListener("loadedmetadata", updateDuration);
    audio.volume = volume;

    return () => {
      audio.removeEventListener("timeupdate", updateTime);
      audio.removeEventListener("loadedmetadata", updateDuration);
    };
  }, [playingId, volume]);

  const handlePlayAudio = (name: NameOfAllah) => {
    if (playingId === name.id) {
      audioRef.current?.pause();
      setPlayingId(null);
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      const audio = new Audio(name.audio);
      audio.volume = volume;
      audioRef.current = audio;
      audio.play();
      setPlayingId(name.id);
      audio.onended = () => {
        setPlayingId(null);
        setCurrentTime(0);
      };
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolume(vol);
    if (audioRef.current) {
      audioRef.current.volume = vol;
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time)) return "0:00";
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <section id="names" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Heart className="w-3 h-3" />
            Asma-ul-Husna
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white mb-6">
            The 99 Names of Allah
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto text-lg">
            Explore the beautiful attributes of the Creator. Each name is a door to understanding His infinite mercy and majesty.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-12 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name or meaning..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white/50 dark:bg-slate-900/50 backdrop-blur-md border border-emerald-100 dark:border-emerald-900 rounded-2xl py-4 pl-12 pr-4 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
          />
        </div>

        {/* Names Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
          <AnimatePresence mode="popLayout">
            {filteredNames.map((name, index) => (
              <motion.div
                key={name.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.02 }}
              >
                <Dialog>
                  <DialogTrigger
                    nativeButton={false}
                    render={
                      <Card
                        onClick={() => setSelectedName(name)}
                        className="group cursor-pointer border-none bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm hover:bg-white/60 dark:hover:bg-slate-900/60 transition-all duration-500 hover:shadow-2xl hover:-translate-y-1"
                      />
                    }
                  >
                    <CardContent className="p-6 text-center">
                      <span className="text-xs font-bold text-emerald-600/50 dark:text-emerald-400/30 block mb-2">
                        #{name.id.toString().padStart(2, "0")}
                      </span>
                      <h3 className="text-3xl font-arabic mb-3 text-slate-900 dark:text-white group-hover:scale-110 transition-transform">
                        {name.arabic}
                      </h3>
                      <p className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                        {name.name}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 italic">
                        {name.meaning}
                      </p>
                    </CardContent>
                  </DialogTrigger>
                  <DialogContent className="fixed inset-0 z-50 w-full h-full max-w-none m-0 rounded-none flex flex-col p-0 overflow-hidden bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl border-none translate-x-0 translate-y-0 left-0 top-0">
                    {selectedName && (
                      <div className="flex flex-col h-full">
                        <div className="h-48 flex-shrink-0 bg-emerald-600/10 dark:bg-emerald-900/20 flex items-center justify-center relative overflow-hidden">
                          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/islamic-art.png')]" />
                          <h2 className="text-8xl font-arabic text-emerald-600 dark:text-emerald-400 relative z-10">
                            {selectedName.arabic}
                          </h2>
                        </div>
                        <ScrollArea className="flex-1">
                          <div className="p-8 max-w-4xl mx-auto">
                            <div className="flex justify-between items-start mb-12">
                              <div>
                                <h3 className="text-5xl font-serif font-bold text-slate-900 dark:text-white mb-2">
                                  {selectedName.name}
                                </h3>
                                <p className="text-2xl text-emerald-600 dark:text-emerald-400 font-medium">
                                  {selectedName.meaning}
                                </p>
                              </div>
                              <div className="flex items-center gap-6">
                                <div className="flex items-center gap-3 bg-slate-100 dark:bg-slate-900 px-4 py-2 rounded-full">
                                  {volume === 0 ? <VolumeX className="w-5 h-5 text-slate-400" /> : volume < 0.5 ? <Volume1 className="w-5 h-5 text-slate-400" /> : <Volume2 className="w-5 h-5 text-slate-400" />}
                                  <input
                                    type="range"
                                    min="0"
                                    max="1"
                                    step="0.01"
                                    value={volume}
                                    onChange={handleVolumeChange}
                                    className="w-24 h-1.5 bg-emerald-200 dark:bg-emerald-800 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                                  />
                                </div>
                                <Button
                                  size="icon"
                                  variant="outline"
                                  onClick={() => handlePlayAudio(selectedName)}
                                  className="rounded-full w-20 h-20 border-emerald-200 dark:border-emerald-800 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 transition-all"
                                >
                                  {playingId === selectedName.id ? (
                                    <Pause className="w-10 h-10" />
                                  ) : (
                                    <Play className="w-10 h-10 ml-1" />
                                  )}
                                </Button>
                              </div>
                            </div>

                            {/* Audio Progress */}
                            <div className="mb-16">
                              <div className="flex justify-between text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">
                                <span>{formatTime(currentTime)}</span>
                                <span>{formatTime(duration)}</span>
                              </div>
                              <input
                                type="range"
                                min="0"
                                max={duration || 0}
                                step="0.1"
                                value={currentTime}
                                onChange={handleSeek}
                                className="w-full h-2 bg-slate-100 dark:bg-slate-900 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                              />
                            </div>

                            <div className="space-y-6">
                              <div className="flex gap-2 items-center text-sm font-bold uppercase tracking-widest text-slate-400">
                                <Info className="w-4 h-4" />
                                Spiritual Significance
                              </div>
                              <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-2xl italic font-serif">
                                "{selectedName.description}"
                              </p>
                            </div>
                          </div>
                        </ScrollArea>
                      </div>
                    )}
                  </DialogContent>
                </Dialog>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};
