import { motion } from "motion/react";
import { Compass, Navigation, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const QiblaFinder = () => {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [qiblaAngle, setQiblaAngle] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState(false);

  const calculateQibla = (lat: number, lng: number) => {
    const kaabaLat = 21.4225;
    const kaabaLng = 39.8262;

    const φ1 = (lat * Math.PI) / 180;
    const λ1 = (lng * Math.PI) / 180;
    const φ2 = (kaabaLat * Math.PI) / 180;
    const λ2 = (kaabaLng * Math.PI) / 180;

    const y = Math.sin(λ2 - λ1);
    const x = Math.cos(φ1) * Math.tan(φ2) - Math.sin(φ1) * Math.cos(λ2 - λ1);
    let qibla = (Math.atan2(y, x) * 180) / Math.PI;
    qibla = (qibla + 360) % 360;
    return qibla;
  };

  const getLocation = () => {
    setIsLocating(true);
    setError(null);
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser.");
      setIsLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setCoords({ lat: latitude, lng: longitude });
        setQiblaAngle(calculateQibla(latitude, longitude));
        setIsLocating(false);
      },
      (err) => {
        setError("Unable to retrieve your location. Please check your permissions.");
        setIsLocating(false);
      }
    );
  };

  return (
    <section id="qibla" className="py-24 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
        >
          <Compass className="w-3 h-3" />
          Qibla Direction
        </motion.div>
        <h2 className="text-4xl font-serif font-bold text-slate-900 dark:text-white mb-6">Find Your Direction</h2>
        <p className="text-slate-600 dark:text-slate-400 mb-12 max-w-lg mx-auto">
          Locate the Kaaba from anywhere in the world to align your heart and prayer.
        </p>

        <div className="flex flex-col items-center gap-8">
          <div className="relative w-64 h-64">
            {/* Compass Background */}
            <div className="absolute inset-0 rounded-full border-4 border-emerald-100 dark:border-emerald-900/50 bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm" />
            
            {/* Compass Markings */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-full h-full p-4 flex flex-col justify-between items-center text-[10px] font-bold text-slate-400 uppercase">
                <span>N</span>
                <div className="w-full flex justify-between px-4">
                  <span>W</span>
                  <span>E</span>
                </div>
                <span>S</span>
              </div>
            </div>

            {/* Qibla Needle */}
            {qiblaAngle !== null && (
              <motion.div
                initial={{ rotate: 0 }}
                animate={{ rotate: qiblaAngle }}
                transition={{ type: "spring", stiffness: 50 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <div className="relative w-1 h-32 bg-emerald-600 rounded-full">
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-emerald-600 rotate-45 rounded-sm shadow-lg shadow-emerald-600/20" />
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 text-[8px] font-bold text-white pt-1">🕋</div>
                </div>
              </motion.div>
            )}

            {/* Center Dot */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-white dark:bg-slate-950 rounded-full border-2 border-emerald-600 z-10" />
          </div>

          <div className="space-y-4">
            {!coords ? (
              <Button
                onClick={getLocation}
                disabled={isLocating}
                className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-full px-8 shadow-lg shadow-emerald-600/20"
              >
                {isLocating ? "Locating..." : "Find Qibla Direction"}
              </Button>
            ) : (
              <div className="text-center">
                <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mb-1">
                  Qibla Angle: {qiblaAngle?.toFixed(2)}°
                </p>
                <p className="text-sm text-slate-500">From North (Clockwise)</p>
                <Button
                  variant="ghost"
                  onClick={getLocation}
                  className="mt-4 text-xs text-emerald-600 hover:text-emerald-700"
                >
                  Update Location
                </Button>
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 text-red-500 text-sm mt-4">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
