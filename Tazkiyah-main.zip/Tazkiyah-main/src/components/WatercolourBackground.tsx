import { motion } from "motion/react";
import { Moon, Star, Sparkles, Wind } from "lucide-react";

export const WatercolourBackground = () => {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none bg-[#fffcf0] dark:bg-[#05070a] transition-colors duration-1000">
      {/* SVG Filters for Organic Edges and Bleeding Effect */}
      <svg className="hidden">
        <defs>
          <filter id="watercolour-bleed">
            <feTurbulence type="fractalNoise" baseFrequency="0.01" numOctaves="5" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="120" />
            <feGaussianBlur stdDeviation="50" />
          </filter>
          <filter id="paper-grain">
            <feTurbulence type="fractalNoise" baseFrequency="0.7" numOctaves="5" stitchTiles="stitch" />
            <feColorMatrix type="saturate" values="0" />
            <feComponentTransfer>
              <feFuncR type="linear" slope="0.4" />
              <feFuncG type="linear" slope="0.4" />
              <feFuncB type="linear" slope="0.4" />
            </feComponentTransfer>
          </filter>
        </defs>
      </svg>

      {/* Floating Islamic Aesthetic Icons */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={`icon-${i}`}
            initial={{ 
              opacity: 0,
              x: Math.random() * 100 + "%",
              y: Math.random() * 100 + "%",
              rotate: Math.random() * 360
            }}
            animate={{ 
              opacity: [0.02, 0.08, 0.02],
              y: ["-10%", "110%"],
              rotate: [0, 360]
            }}
            transition={{ 
              duration: 20 + Math.random() * 20,
              repeat: Infinity,
              ease: "linear",
              delay: Math.random() * -20
            }}
            className="absolute text-emerald-600 dark:text-emerald-400"
          >
            {i % 3 === 0 ? <Moon className="w-12 h-12" /> : i % 3 === 1 ? <Star className="w-8 h-8" /> : <Sparkles className="w-10 h-10" />}
          </motion.div>
        ))}
      </div>

      {/* Stars for Dark Mode */}
      <div className="absolute inset-0 opacity-0 dark:opacity-30 transition-opacity duration-1000">
        {[...Array(40)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: Math.random() }}
            animate={{ opacity: [0.1, 0.8, 0.1] }}
            transition={{
              duration: 3 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
            className="absolute bg-amber-100 rounded-full"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 1.5 + 0.5}px`,
              height: `${Math.random() * 1.5 + 0.5}px`,
              boxShadow: "0 0 8px rgba(254, 243, 199, 0.4)",
            }}
          />
        ))}
      </div>

      {/* Primary Watercolour Layers */}
      <div style={{ filter: "url(#watercolour-bleed)" }} className="absolute inset-0 opacity-70 dark:opacity-60">
        {/* Teal/Emerald Blob */}
        <motion.div
          animate={{
            scale: [1, 1.4, 1],
            rotate: [0, 20, 0],
            x: [-40, 60, -40],
            y: [-20, 40, -20],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-[15%] -left-[10%] w-[85%] h-[85%] bg-emerald-300/40 dark:bg-emerald-900/40 rounded-full mix-blend-multiply dark:mix-blend-screen"
        />
        
        {/* Deep Blue/Indigo Blob */}
        <motion.div
          animate={{
            scale: [1.2, 0.8, 1.2],
            rotate: [0, -15, 0],
            x: [60, -40, 60],
            y: [40, -50, 40],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[20%] -right-[15%] w-[80%] h-[80%] bg-blue-300/30 dark:bg-indigo-950/50 rounded-full mix-blend-multiply dark:mix-blend-screen"
        />

        {/* Warm Amber/Gold Blob */}
        <motion.div
          animate={{
            scale: [0.8, 1.3, 0.8],
            rotate: [0, 15, 0],
            x: [-50, 70, -50],
            y: [70, -30, 70],
          }}
          transition={{ duration: 30, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -bottom-[20%] left-[20%] w-[90%] h-[90%] bg-amber-200/40 dark:bg-amber-900/30 rounded-full mix-blend-multiply dark:mix-blend-screen"
        />

        {/* Soft Rose/Terracotta Accent */}
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            x: [50, -50, 50],
            y: [-40, 40, -40],
          }}
          transition={{ duration: 40, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[40%] left-[30%] w-[50%] h-[50%] bg-rose-100/20 dark:bg-rose-950/10 rounded-full mix-blend-multiply dark:mix-blend-screen"
        />
      </div>

      {/* Secondary Blending Layer for "Wet" Look */}
      <div className="absolute inset-0 opacity-20 dark:opacity-10 mix-blend-overlay">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 via-transparent to-amber-500/10" />
      </div>

      {/* Artistic Textures & Patterns */}
      <div className="absolute inset-0 opacity-[0.06] dark:opacity-[0.03] pointer-events-none">
        <img 
          src="https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&q=80&w=1200" 
          alt="" 
          className="absolute top-0 right-0 w-3/4 h-3/4 object-cover mix-blend-multiply dark:mix-blend-overlay blur-md"
          referrerPolicy="no-referrer"
        />
        <img 
          src="https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&q=80&w=1200" 
          alt="" 
          className="absolute bottom-0 left-0 w-3/4 h-3/4 object-cover mix-blend-multiply dark:mix-blend-overlay blur-md"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Islamic Pattern Overlay */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/islamic-art.png')] opacity-[0.04] dark:opacity-[0.02] mix-blend-overlay" />

      {/* Paper Texture & Grain */}
      <div className="absolute inset-0 opacity-[0.1] dark:opacity-[0.05] mix-blend-multiply dark:mix-blend-overlay pointer-events-none" 
           style={{ filter: "url(#paper-grain)" }} />
      
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')] opacity-[0.2] dark:opacity-[0.08] mix-blend-multiply dark:mix-blend-soft-light" />

      {/* Global Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_rgba(0,0,0,0.02)_100%)] dark:bg-[radial-gradient(circle_at_center,_transparent_0%,_rgba(0,0,0,0.3)_100%)]" />
    </div>
  );
};
