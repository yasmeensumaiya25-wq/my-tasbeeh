import { motion, AnimatePresence } from "motion/react";
import { Home, Book, History, Fingerprint, Compass, Calculator, Calendar, Heart, Sparkles, BookOpen, Sun, Moon, MoreHorizontal, MessageSquare } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useTheme } from "./ThemeProvider";
import { Button } from "@/components/ui/button";

const navItems = [
  { name: "Home", icon: Home, href: "#home" },
  { name: "Names", icon: Heart, href: "#names" },
  { name: "Quran", icon: BookOpen, href: "#quran" },
  { name: "Prayer", icon: History, href: "#prayer-times" },
  { name: "Dhikr", icon: Sparkles, href: "#dhikr" },
];

const moreItems = [
  { name: "Tasbih", icon: Fingerprint, href: "#tasbih" },
  { name: "Journal", icon: Book, href: "#journal" },
  { name: "Qibla", icon: Compass, href: "#qibla" },
  { name: "Zakat", icon: Calculator, href: "#zakat" },
  { name: "Seerah", icon: History, href: "#seerah" },
  { name: "Duas", icon: MessageSquare, href: "#duas" },
  { name: "Calendar", icon: Calendar, href: "#calendar" },
];

export const BottomNav = () => {
  const [active, setActive] = useState("#home");
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const moreMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(event.target as Node)) {
        setIsMoreOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const allItems = [...navItems, ...moreItems];
      const sections = allItems.map(item => document.querySelector(item.href));
      const scrollPos = window.scrollY + 200;

      sections.forEach((section, i) => {
        if (section && section instanceof HTMLElement) {
          if (section.offsetTop <= scrollPos && section.offsetTop + section.offsetHeight > scrollPos) {
            setActive(allItems[i].href);
          }
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-4xl">
      <AnimatePresence>
        {isMoreOpen && (
          <motion.div
            ref={moreMenuRef}
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-full mb-4 left-0 right-0 bg-white/90 dark:bg-slate-950/90 backdrop-blur-2xl border border-emerald-100 dark:border-emerald-900 rounded-[2.5rem] p-6 shadow-2xl grid grid-cols-4 gap-4"
          >
            {moreItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={() => {
                  setActive(item.href);
                  setIsMoreOpen(false);
                }}
                className="flex flex-col items-center gap-2 p-3 rounded-2xl hover:bg-emerald-50 dark:hover:bg-emerald-900/30 transition-colors group"
              >
                <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-400 group-hover:text-emerald-600 transition-colors">
                  <item.icon className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-tight text-slate-500 dark:text-slate-400">
                  {item.name}
                </span>
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border border-emerald-100 dark:border-emerald-900 rounded-3xl p-2 shadow-2xl flex justify-between items-center gap-1">
        {navItems.map((item) => {
          const isActive = active === item.href;
          return (
            <a
              key={item.name}
              href={item.href}
              onClick={() => setActive(item.href)}
              className={`relative flex flex-col items-center justify-center flex-1 py-2 rounded-2xl transition-all duration-300 ${
                isActive ? "text-emerald-600" : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="active-nav"
                  className="absolute inset-0 bg-emerald-50 dark:bg-emerald-900/30 rounded-2xl -z-10"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
              <item.icon className={`w-5 h-5 mb-1 transition-transform ${isActive ? "scale-110" : ""}`} />
              <span className="text-[10px] font-bold uppercase tracking-tighter hidden sm:block">
                {item.name}
              </span>
            </a>
          );
        })}
        
        <button
          onClick={() => setIsMoreOpen(!isMoreOpen)}
          className={`relative flex flex-col items-center justify-center flex-1 py-2 rounded-2xl transition-all duration-300 ${
            isMoreOpen ? "text-emerald-600" : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          }`}
        >
          {isMoreOpen && (
            <motion.div
              layoutId="active-nav"
              className="absolute inset-0 bg-emerald-50 dark:bg-emerald-900/30 rounded-2xl -z-10"
            />
          )}
          <MoreHorizontal className={`w-5 h-5 mb-1 transition-transform ${isMoreOpen ? "scale-110" : ""}`} />
          <span className="text-[10px] font-bold uppercase tracking-tighter hidden sm:block">
            More
          </span>
        </button>

        <div className="w-px h-8 bg-slate-200 dark:bg-slate-800 mx-1" />
        
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="rounded-2xl w-12 h-12 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 transition-all duration-500"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={theme}
              initial={{ opacity: 0, rotate: -90, scale: 0.5 }}
              animate={{ opacity: 1, rotate: 0, scale: 1 }}
              exit={{ opacity: 0, rotate: 90, scale: 0.5 }}
              transition={{ duration: 0.3 }}
            >
              {theme === "dark" ? (
                <Sun className="w-5 h-5 text-amber-400" />
              ) : (
                <Moon className="w-5 h-5 text-slate-700" />
              )}
            </motion.div>
          </AnimatePresence>
        </Button>
      </div>
    </nav>
  );
};
