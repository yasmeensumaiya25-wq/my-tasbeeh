import { motion } from "motion/react";
import { Calculator, Info, Wallet } from "lucide-react";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const ZakatCalculator = () => {
  const [assets, setAssets] = useState({
    cash: 0,
    gold: 0,
    silver: 0,
    investments: 0,
    business: 0,
  });

  const nisabGold = 85; // grams
  const goldPrice = 65; // USD per gram (approx)
  const nisabValue = nisabGold * goldPrice;

  const totalAssets = Object.values(assets).reduce((a, b) => (a as number) + (b as number), 0) as number;
  const zakatDue = totalAssets >= nisabValue ? totalAssets * 0.025 : 0;

  const handleInputChange = (field: keyof typeof assets, value: string) => {
    const num = parseFloat(value) || 0;
    setAssets(prev => ({ ...prev, [field]: num }));
  };

  return (
    <section id="zakat" className="py-24 px-6 bg-emerald-50/20 dark:bg-emerald-900/5">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <Calculator className="w-3 h-3" />
            Zakat Calculator
          </motion.div>
          <h2 className="text-4xl font-serif font-bold text-slate-900 dark:text-white mb-4">Purify Your Wealth</h2>
          <p className="text-slate-600 dark:text-slate-400">Calculate your annual Zakat contribution with ease and transparency.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="border-none bg-white/60 dark:bg-slate-900/60 backdrop-blur-md shadow-xl">
            <CardHeader>
              <CardTitle className="text-lg font-serif">Enter Your Assets</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.keys(assets).map((key) => (
                <div key={key} className="space-y-1">
                  <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                    {key.charAt(0).toUpperCase() + key.slice(1)} (USD)
                  </label>
                  <input
                    type="number"
                    value={assets[key as keyof typeof assets] || ""}
                    onChange={(e) => handleInputChange(key as keyof typeof assets, e.target.value)}
                    className="w-full bg-emerald-50/50 dark:bg-emerald-900/20 border-none rounded-xl px-4 py-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 transition-all"
                    placeholder="0.00"
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="border-none bg-emerald-600 text-white shadow-xl shadow-emerald-600/20">
              <CardContent className="p-8 text-center">
                <Wallet className="w-12 h-12 text-emerald-300/50 mx-auto mb-4" />
                <p className="text-sm font-bold uppercase tracking-widest text-emerald-100 mb-2">Total Zakat Due</p>
                <h3 className="text-5xl font-serif font-bold mb-4">
                  ${zakatDue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </h3>
                <p className="text-xs text-emerald-200">
                  {totalAssets < nisabValue 
                    ? `Your total assets ($${totalAssets.toLocaleString()}) are below the Nisab threshold ($${nisabValue.toLocaleString()}).`
                    : "Based on 2.5% of your total zakatable assets."}
                </p>
              </CardContent>
            </Card>

            <div className="p-6 rounded-2xl bg-white/40 dark:bg-slate-900/40 border border-emerald-100 dark:border-emerald-900 backdrop-blur-sm">
              <div className="flex gap-3">
                <Info className="w-5 h-5 text-emerald-600 shrink-0" />
                <div className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  <p className="font-bold mb-1">About Nisab</p>
                  Nisab is the minimum amount of wealth a Muslim must possess before Zakat becomes obligatory. 
                  It is typically equivalent to 85g of gold or 595g of silver.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
