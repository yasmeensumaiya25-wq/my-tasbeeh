import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { CheckCircle2, Circle, Trophy, History } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format, subDays } from "date-fns";

const PRAYERS = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"];

export const PrayerTracker = () => {
  const [history, setHistory] = useState<Record<string, string[]>>({});

  useEffect(() => {
    const saved = localStorage.getItem("tazkiyah-prayer-history");
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const togglePrayer = (date: string, prayer: string) => {
    const currentDay = history[date] || [];
    const updatedDay = currentDay.includes(prayer)
      ? currentDay.filter((p) => p !== prayer)
      : [...currentDay, prayer];
    
    const updatedHistory = { ...history, [date]: updatedDay };
    setHistory(updatedHistory);
    localStorage.setItem("tazkiyah-prayer-history", JSON.stringify(updatedHistory));
  };

  const last5Days = [...Array(5)].map((_, i) => {
    const d = subDays(new Date(), i);
    return format(d, "yyyy-MM-dd");
  });

  const calculateStreak = () => {
    let streak = 0;
    for (const date of last5Days) {
      if ((history[date]?.length || 0) === 5) streak++;
      else break;
    }
    return streak;
  };

  return (
    <section id="prayer-tracker" className="py-24 px-6 bg-emerald-50/10 dark:bg-emerald-900/5">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-16">
          <div className="text-center md:text-left">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
            >
              <History className="w-3 h-3" />
              Consistency
            </motion.div>
            <h2 className="text-4xl font-serif font-bold text-slate-900 dark:text-white mb-4">Prayer Tracker</h2>
            <p className="text-slate-600 dark:text-slate-400">Track your journey of devotion over the past 5 days.</p>
          </div>

          <Card className="border-none bg-emerald-600 text-white shadow-xl shadow-emerald-600/20 px-8 py-6 rounded-3xl flex items-center gap-6">
            <div className="p-4 rounded-2xl bg-white/20">
              <Trophy className="w-8 h-8" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-100">Current Streak</p>
              <h3 className="text-4xl font-serif font-bold">{calculateStreak()} Days</h3>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {last5Days.map((date, i) => (
            <motion.div
              key={date}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className={`border-none transition-all duration-500 ${
                (history[date]?.length || 0) === 5 
                  ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/20" 
                  : "bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm"
              }`}>
                <CardHeader className="p-6 text-center border-b border-black/5 dark:border-white/5">
                  <p className="text-[10px] font-bold uppercase tracking-widest opacity-60">
                    {i === 0 ? "Today" : format(new Date(date), "EEEE")}
                  </p>
                  <CardTitle className="text-lg font-serif">
                    {format(new Date(date), "MMM d")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-2">
                  {PRAYERS.map((prayer) => {
                    const isDone = history[date]?.includes(prayer);
                    return (
                      <button
                        key={prayer}
                        onClick={() => togglePrayer(date, prayer)}
                        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                          isDone 
                            ? "bg-white/20 text-white" 
                            : "hover:bg-emerald-50 dark:hover:bg-emerald-900/20 text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        <span className="text-sm font-medium">{prayer}</span>
                        {isDone ? <CheckCircle2 className="w-4 h-4" /> : <Circle className="w-4 h-4 opacity-20" />}
                      </button>
                    );
                  })}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
