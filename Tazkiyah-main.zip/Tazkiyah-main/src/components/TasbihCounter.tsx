import { motion, AnimatePresence } from "motion/react";
import { RotateCcw, Plus, Fingerprint, Sparkles } from "lucide-react";
import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";

export const TasbihCounter = () => {
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(33);
  const [totalCount, setTotalCount] = useState(0);

  const increment = useCallback(() => {
    setCount(prev => prev + 1);
    setTotalCount(prev => prev + 1);
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }
  }, []);

  const reset = () => {
    setCount(0);
  };

  const progress = (count % target) / target;

  return (
    <section id="tasbih" className="py-24 px-6 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/5 dark:bg-emerald-500/10 rounded-full blur-[120px] -z-10" />
      
      <div className="max-w-md mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
        >
          <Fingerprint className="w-3 h-3" />
          Digital Tasbih
        </motion.div>
        <h2 className="text-4xl font-serif font-bold text-slate-900 dark:text-white mb-2">Tasbih Counter</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-12">Keep track of your dhikr with every tap.</p>

        <div className="relative">
          {/* Counter Display */}
          <div className="relative w-72 h-72 mx-auto mb-12 flex items-center justify-center">
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle
                cx="144"
                cy="144"
                r="130"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="text-emerald-100 dark:text-emerald-900/20"
              />
              <motion.circle
                cx="144"
                cy="144"
                r="130"
                fill="none"
                stroke="currentColor"
                strokeWidth="6"
                strokeDasharray="816.8"
                animate={{ strokeDashoffset: 816.8 - (816.8 * progress) }}
                className="text-emerald-600"
                strokeLinecap="round"
                transition={{ type: "spring", stiffness: 50, damping: 15 }}
              />
            </svg>
            
            <div className="text-center z-10">
              <div className="flex items-center justify-center gap-1 text-emerald-600/50 mb-2">
                <Sparkles className="w-3 h-3" />
                <span className="text-[10px] font-bold uppercase tracking-widest">Session</span>
              </div>
              <AnimatePresence mode="wait">
                <motion.span
                  key={count}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-8xl font-serif font-bold text-slate-900 dark:text-white block leading-none"
                >
                  {count}
                </motion.span>
              </AnimatePresence>
              <div className="mt-4 flex flex-col items-center">
                <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Target: {target}
                </span>
                <div className="mt-2 w-24 h-1 bg-emerald-100 dark:bg-emerald-900/30 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-emerald-600"
                    animate={{ width: `${progress * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Fingerprint Tap Area */}
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={increment}
            className="w-full aspect-square max-w-[240px] mx-auto rounded-full bg-white dark:bg-slate-900 shadow-2xl flex flex-col items-center justify-center group relative overflow-hidden mb-12 border-4 border-emerald-100 dark:border-emerald-900"
          >
            {/* Fingerprint SVG Background */}
            <div className="absolute inset-0 opacity-20 dark:opacity-40 group-hover:opacity-40 dark:group-hover:opacity-60 transition-opacity">
              <svg viewBox="0 0 100 100" className="w-full h-full text-emerald-600">
                <path d="M50,10 C30,10 10,30 10,50 C10,70 30,90 50,90 C70,90 90,70 90,50 C90,30 70,10 50,10 M50,20 C65,20 80,35 80,50 C80,65 65,80 50,80 C35,80 20,65 20,50 C20,35 35,20 50,20 M50,30 C58,30 65,37 65,45 L65,55 C65,63 58,70 50,70 C42,70 35,63 35,55 L35,45 C35,37 42,30 50,30 M50,40 C53,40 55,42 55,45 L55,55 C55,58 53,60 50,60 C47,60 45,58 45,55 L45,45 C45,42 47,40 50,40" fill="none" stroke="currentColor" strokeWidth="1" />
                <path d="M30,50 Q30,30 50,30 Q70,30 70,50" fill="none" stroke="currentColor" strokeWidth="1" />
                <path d="M20,50 Q20,20 50,20 Q80,20 80,50" fill="none" stroke="currentColor" strokeWidth="1" />
                <path d="M40,50 Q40,40 50,40 Q60,40 60,50" fill="none" stroke="currentColor" strokeWidth="1" />
              </svg>
            </div>
            
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-emerald-600/10 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                <Fingerprint className="w-8 h-8 text-emerald-600" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600">Tap to Count</span>
            </div>
            
            {/* Ripple Effect on Tap */}
            <AnimatePresence>
              <motion.div
                key={count}
                initial={{ scale: 0, opacity: 0.5 }}
                animate={{ scale: 2, opacity: 0 }}
                className="absolute inset-0 bg-emerald-600 rounded-full pointer-events-none"
              />
            </AnimatePresence>
          </motion.button>

          <div className="flex flex-col gap-6">
            <div className="flex justify-center gap-3">
              {[33, 99, 100, 1000].map(val => (
                <button
                  key={val}
                  onClick={() => setTarget(val)}
                  className={`px-5 py-2 rounded-2xl text-xs font-bold transition-all border ${
                    target === val 
                      ? "bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-600/20" 
                      : "bg-white/50 dark:bg-slate-900/50 text-emerald-600 border-emerald-100 dark:border-emerald-900"
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>
            
            <div className="flex items-center justify-center gap-8">
              <div className="text-left">
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Total Taps</p>
                <p className="text-xl font-serif font-bold text-slate-900 dark:text-white">{totalCount}</p>
              </div>
              <div className="w-px h-8 bg-slate-200 dark:bg-slate-800" />
              <Button
                variant="ghost"
                onClick={reset}
                className="rounded-2xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
              >
                <RotateCcw className="w-4 h-4 mr-2" /> Reset Session
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
