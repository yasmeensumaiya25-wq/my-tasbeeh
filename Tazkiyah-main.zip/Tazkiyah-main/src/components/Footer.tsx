import { motion } from "motion/react";
import { Heart, Mail, Github, Twitter, Instagram } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="py-12 px-6 border-t border-emerald-100 dark:border-emerald-900 bg-white/30 dark:bg-slate-950/30 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-serif font-bold">T</span>
              </div>
              <span className="text-xl font-serif font-bold tracking-tight text-emerald-900 dark:text-emerald-50">
                Tazkiyah
              </span>
            </div>
            <p className="text-slate-600 dark:text-slate-400 max-w-sm mb-6">
              A digital sanctuary for the modern Muslim. Purify your heart, 
              remember your Creator, and find peace in the divine.
            </p>
            <div className="flex gap-4">
              {[Twitter, Instagram, Github, Mail].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400 hover:bg-emerald-600 hover:text-white transition-all"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 dark:text-white mb-6">Quick Links</h4>
            <ul className="space-y-4">
              {["Home", "99 Names", "Calendar", "Prayer Times"].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(" ", "-")}`} className="text-slate-600 dark:text-slate-400 hover:text-emerald-600 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 dark:text-white mb-6">Resources</h4>
            <ul className="space-y-4">
              {["Quran Explorer", "Dua Collection", "Islamic Blog", "Community"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-slate-600 dark:text-slate-400 hover:text-emerald-600 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-emerald-100/50 dark:border-emerald-900/50 flex flex-col md:row items-center justify-between gap-4">
          <p className="text-sm text-slate-500 dark:text-slate-500">
            © {new Date().getFullYear()} Tazkiyah. All rights reserved.
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-500 flex items-center gap-1">
            Made with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for the Ummah
          </p>
        </div>
      </div>
    </footer>
  );
};
