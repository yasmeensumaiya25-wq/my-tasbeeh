import { motion } from "motion/react";
import { History, Star, Heart, Shield, BookOpen } from "lucide-react";

const timelineEvents = [
  {
    year: "570 CE",
    title: "Year of the Elephant",
    description: "The birth of Prophet Muhammad (PBUH) in Makkah. He was born an orphan, his father Abdullah having passed away before his birth.",
    icon: Star,
    category: "Birth"
  },
  {
    year: "576 CE",
    title: "Loss of Mother",
    description: "At the age of six, he lost his mother, Aminah. He was then cared for by his grandfather, Abdul Muttalib.",
    icon: Heart,
    category: "Childhood"
  },
  {
    year: "595 CE",
    title: "Marriage to Khadijah (RA)",
    description: "At 25, he married Khadijah (RA), a noble businesswoman. Their marriage was one of deep love, respect, and support.",
    icon: Shield,
    category: "Adulthood"
  },
  {
    year: "610 CE",
    title: "The First Revelation",
    description: "At 40, in the Cave of Hira, the Angel Jibril brought the first verses of the Quran: 'Read in the name of your Lord who created.'",
    icon: BookOpen,
    category: "Prophethood"
  },
  {
    year: "613 CE",
    title: "Public Preaching",
    description: "After three years of private invitation, the Prophet (PBUH) began preaching Islam publicly in Makkah.",
    icon: History,
    category: "Mission"
  },
  {
    year: "622 CE",
    title: "The Hijrah",
    description: "Migration from Makkah to Madinah, marking the beginning of the Islamic (Hijri) calendar and the establishment of the first Islamic state.",
    icon: Star,
    category: "Migration"
  },
  {
    year: "630 CE",
    title: "Conquest of Makkah",
    description: "The Prophet (PBUH) returned to Makkah with a large army. He entered peacefully, granted general amnesty, and purified the Kaaba.",
    icon: Shield,
    category: "Victory"
  },
  {
    year: "632 CE",
    title: "The Farewell Pilgrimage",
    description: "The Prophet (PBUH) performed his final Hajj and delivered the Farewell Sermon, emphasizing equality and justice.",
    icon: Heart,
    category: "Final Year"
  }
];

export const SeerahTimeline = () => {
  return (
    <section id="seerah" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            <History className="w-3 h-3" />
            The Prophet's Life
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white mb-6">
            Seerah Timeline
          </h2>
          <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto text-lg">
            A journey through the life of the Final Messenger (PBUH), from his blessed birth to the completion of his mission.
          </p>
        </div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-emerald-200 dark:via-emerald-800 to-transparent hidden md:block" />

          <div className="space-y-12 md:space-y-24">
            {timelineEvents.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`flex flex-col md:flex-row items-center gap-8 ${
                  index % 2 === 0 ? "md:flex-row-reverse" : ""
                }`}
              >
                {/* Content */}
                <div className="flex-1 w-full">
                  <div className={`p-8 rounded-3xl bg-white/40 dark:bg-slate-900/40 backdrop-blur-md border border-emerald-100/50 dark:border-emerald-900/50 hover:shadow-2xl transition-all duration-500 ${
                    index % 2 === 0 ? "md:text-left" : "md:text-right"
                  }`}>
                    <span className="text-xs font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400 mb-2 block">
                      {event.category} • {event.year}
                    </span>
                    <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white mb-4">
                      {event.title}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                      {event.description}
                    </p>
                  </div>
                </div>

                {/* Center Icon */}
                <div className="relative z-10 flex items-center justify-center w-16 h-16 rounded-full bg-emerald-600 text-white shadow-xl shadow-emerald-600/20">
                  <event.icon className="w-6 h-6" />
                  {/* Pulse Effect */}
                  <div className="absolute inset-0 rounded-full bg-emerald-600 animate-ping opacity-20" />
                </div>

                {/* Spacer for Desktop */}
                <div className="flex-1 hidden md:block" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
