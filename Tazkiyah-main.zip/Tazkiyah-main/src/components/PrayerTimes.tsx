import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Clock, MapPin, Navigation, Loader2, Compass } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Coordinates, CalculationMethod, PrayerTimes as AdhanPrayerTimes } from "adhan";
import { format } from "date-fns";

export const PrayerTimes = () => {
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [address, setAddress] = useState<string>("Detecting location...");
  const [times, setTimes] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          setLocation({ lat: latitude, lng: longitude });
          calculateTimes(latitude, longitude);
          setLoading(false);
          setAddress(`Lat: ${latitude.toFixed(2)}, Lng: ${longitude.toFixed(2)}`);
        },
        (err) => {
          console.error(err);
          // Fallback to London if blocked
          calculateTimes(51.5074, -0.1278);
          setAddress("Default: London (GPS Blocked)");
          setLoading(false);
        }
      );
    }
  }, []);

  const calculateTimes = (lat: number, lng: number) => {
    const coords = new Coordinates(lat, lng);
    const params = CalculationMethod.MuslimWorldLeague();
    const date = new Date();
    const prayerTimes = new AdhanPrayerTimes(coords, date, params);
    
    setTimes({
      Fajr: prayerTimes.fajr,
      Sunrise: prayerTimes.sunrise,
      Dhuhr: prayerTimes.dhuhr,
      Asr: prayerTimes.asr,
      Maghrib: prayerTimes.maghrib,
      Isha: prayerTimes.isha,
    });
  };

  const prayerList = times ? Object.entries(times).map(([name, time]) => ({
    name,
    time: format(time as Date, "h:mm a"),
  })) : [];

  return (
    <section id="prayer-times" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase tracking-widest mb-4"
            >
              <Navigation className="w-3 h-3" />
              GPS Tracker Active
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 dark:text-white mb-6">
              Prayer Times
            </h2>
            <div className="flex items-center gap-3 p-4 rounded-2xl bg-white/40 dark:bg-slate-900/40 backdrop-blur-sm border border-emerald-100/50 dark:border-emerald-900/50 mb-8">
              <div className="p-3 rounded-xl bg-emerald-600 text-white">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Current Location</p>
                <p className="text-sm font-medium text-slate-900 dark:text-white">{address}</p>
              </div>
            </div>
            
            <div className="p-8 rounded-3xl bg-emerald-600 text-white shadow-2xl shadow-emerald-600/20 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Compass className="w-32 h-32 rotate-12" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-100 mb-2">Current Time</p>
              <h3 className="text-5xl font-serif font-bold mb-2">{format(currentTime, "h:mm:ss")}</h3>
              <p className="text-emerald-100/60 font-medium">{format(currentTime, "EEEE, MMMM do")}</p>
            </div>
          </div>

          <div className="lg:col-span-2">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {prayerList.map((prayer, i) => (
                  <motion.div
                    key={prayer.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card className="border-none bg-white/60 dark:bg-slate-900/60 backdrop-blur-md hover:bg-emerald-600 hover:text-white transition-all duration-500 group">
                      <CardContent className="p-8 text-center">
                        <Clock className="w-6 h-6 mx-auto mb-4 text-emerald-600 group-hover:text-white transition-colors" />
                        <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 group-hover:text-emerald-100 mb-2">
                          {prayer.name}
                        </h4>
                        <p className="text-2xl font-serif font-bold">
                          {prayer.time}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
