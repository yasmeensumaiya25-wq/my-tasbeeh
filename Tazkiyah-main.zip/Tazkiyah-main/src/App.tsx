/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ThemeProvider } from "./components/ThemeProvider";
import { Hero } from "./components/Hero";
import { NamesSection } from "./components/NamesSection";
import { CalendarSection } from "./components/CalendarSection";
import { PrayerTimes } from "./components/PrayerTimes";
import { DailyDhikr } from "./components/DailyDhikr";
import { QuranQuote } from "./components/QuranQuote";
import { QiblaFinder } from "./components/QiblaFinder";
import { ZakatCalculator } from "./components/ZakatCalculator";
import { TasbihCounter } from "./components/TasbihCounter";
import { DuaCollection } from "./components/DuaCollection";
import { SeerahTimeline } from "./components/SeerahTimeline";
import { JournalSection } from "./components/JournalSection";
import { PrayerTracker } from "./components/PrayerTracker";
import { BottomNav } from "./components/BottomNav";
import { BeautyOfIslam } from "./components/BeautyOfIslam";
import { QuranSection } from "./components/QuranSection";
import { Footer } from "./components/Footer";
import { WatercolourBackground } from "./components/WatercolourBackground";
import { ThemeToggle } from "./components/ThemeToggle";
import { AyahJar } from "./components/AyahJar";
import { Reminders } from "./components/Reminders";

export default function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="tazkiyah-theme">
      <div className="min-h-screen font-sans selection:bg-emerald-200 selection:text-emerald-900 dark:selection:bg-emerald-800 dark:selection:text-emerald-100 pb-24">
        <ThemeToggle />
        <WatercolourBackground />
        <main>
          <Hero />
          <Reminders />
          <AyahJar />
          <QuranQuote />
          <NamesSection />
          <BeautyOfIslam />
          <QuranSection />
          <PrayerTimes />
          <PrayerTracker />
          <DailyDhikr />
          <TasbihCounter />
          <SeerahTimeline />
          <JournalSection />
          <QiblaFinder />
          <ZakatCalculator />
          <DuaCollection />
          <CalendarSection />
        </main>
        <Footer />
        <BottomNav />
      </div>
    </ThemeProvider>
  );
}
